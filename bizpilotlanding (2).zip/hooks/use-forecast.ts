"use client"

import { useState } from "react"
import type { ForecastFormData } from "@/components/forecasting/forecast-form"

interface ForecastResult {
  demand: number[]
  production: number[]
  inventory: number[]
  staffing: number[]
  confidence: number
  factors: string[]
  recommendations: string[]
}

interface ForecastResponse {
  success: boolean
  data: {
    forecast: ForecastResult
    insights: string[]
    metadata: {
      location: string
      countryCode: string
      businessType: string
      timeHorizon: number
      generatedAt: string
    }
  }
  error?: string
}

export function useForecast() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<ForecastResponse | null>(null)

  const generateForecast = async (formData: ForecastFormData) => {
    setLoading(true)
    setError(null)

    try {
      // Parse historical data if provided
      let historicalData = []
      if (formData.historicalData.trim()) {
        try {
          // Try to parse as JSON first
          historicalData = JSON.parse(formData.historicalData)
        } catch {
          // If not JSON, split by lines and try to extract numbers
          const lines = formData.historicalData.split("\n").filter((line) => line.trim())
          historicalData = lines
            .map((line) => {
              const numbers = line.match(/\d+\.?\d*/g)
              return numbers ? numbers.map(Number) : []
            })
            .filter((arr) => arr.length > 0)
        }
      }

      const response = await fetch("/api/forecast", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          location: formData.location,
          countryCode: formData.countryCode,
          businessType: formData.businessType,
          timeHorizon: formData.timeHorizon,
          historicalData,
          businessContext: formData.businessContext,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to generate forecast")
      }

      setResult(data)
      return data
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "An unexpected error occurred"
      setError(errorMessage)
      throw err
    } finally {
      setLoading(false)
    }
  }

  const reset = () => {
    setResult(null)
    setError(null)
    setLoading(false)
  }

  return {
    generateForecast,
    loading,
    error,
    result,
    reset,
  }
}
