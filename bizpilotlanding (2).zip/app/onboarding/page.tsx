"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Zap, ArrowRight, ArrowLeft, MapPin, Briefcase, Target, DollarSign } from "lucide-react"

export default function OnboardingPage() {
  const [currentStep, setCurrentStep] = useState(1)
  const [userData, setUserData] = useState<any>(null)
  const [onboardingData, setOnboardingData] = useState({
    language: "",
    location: "",
    businessStage: "",
    industry: "",
    budget: "",
    goals: "",
    experience: "",
  })
  const router = useRouter()

  useEffect(() => {
    // Check if user is authenticated
    const user = localStorage.getItem("bizpilot_user")
    if (!user) {
      router.push("/auth/login")
      return
    }
    setUserData(JSON.parse(user))
  }, [router])

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1)
    } else {
      // Complete onboarding
      const updatedUser = {
        ...userData,
        onboarding: onboardingData,
        onboardingComplete: true,
      }
      localStorage.setItem("bizpilot_user", JSON.stringify(updatedUser))
      router.push("/dashboard")
    }
  }

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const progress = (currentStep / 4) * 100

  if (!userData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">Loading...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-accent-foreground" />
              </div>
              <span className="text-xl font-bold">BizPilot</span>
            </div>
            <h1 className="text-3xl font-bold mb-2">Welcome, {userData.name}!</h1>
            <p className="text-muted-foreground">Let's personalize your experience</p>
            <div className="mt-4">
              <Progress value={progress} className="w-full" />
              <p className="text-sm text-muted-foreground mt-2">Step {currentStep} of 4</p>
            </div>
          </div>

          <Card>
            <CardContent className="p-6">
              {/* Step 1: Language & Location */}
              {currentStep === 1 && (
                <div className="space-y-6">
                  <div className="text-center">
                    <MapPin className="w-12 h-12 text-accent mx-auto mb-4" />
                    <CardTitle className="text-2xl mb-2">Where are you located?</CardTitle>
                    <CardDescription>This helps us provide region-specific insights</CardDescription>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="language">Preferred Language</Label>
                      <Select
                        value={onboardingData.language}
                        onValueChange={(value) => setOnboardingData({ ...onboardingData, language: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select your language" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="english">English</SelectItem>
                          <SelectItem value="bengali">Bengali</SelectItem>
                          <SelectItem value="hindi">Hindi</SelectItem>
                          <SelectItem value="urdu">Urdu</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        placeholder="e.g., Dhaka, Bangladesh"
                        value={onboardingData.location}
                        onChange={(e) => setOnboardingData({ ...onboardingData, location: e.target.value })}
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Step 2: Business Stage */}
              {currentStep === 2 && (
                <div className="space-y-6">
                  <div className="text-center">
                    <Briefcase className="w-12 h-12 text-accent mx-auto mb-4" />
                    <CardTitle className="text-2xl mb-2">What's your business stage?</CardTitle>
                    <CardDescription>Help us understand where you are in your journey</CardDescription>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[
                      { value: "idea", label: "Just an idea", desc: "I have a business concept" },
                      { value: "planning", label: "Planning stage", desc: "Working on business plan" },
                      { value: "startup", label: "Early startup", desc: "Recently launched" },
                      { value: "growing", label: "Growing business", desc: "Looking to scale" },
                    ].map((stage) => (
                      <Card
                        key={stage.value}
                        className={`cursor-pointer transition-colors ${
                          onboardingData.businessStage === stage.value ? "border-accent bg-accent/5" : ""
                        }`}
                        onClick={() => setOnboardingData({ ...onboardingData, businessStage: stage.value })}
                      >
                        <CardContent className="p-4 text-center">
                          <h3 className="font-semibold mb-1">{stage.label}</h3>
                          <p className="text-sm text-muted-foreground">{stage.desc}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  <div>
                    <Label htmlFor="industry">Industry/Sector</Label>
                    <Select
                      value={onboardingData.industry}
                      onValueChange={(value) => setOnboardingData({ ...onboardingData, industry: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select your industry" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ecommerce">E-commerce</SelectItem>
                        <SelectItem value="food">Food & Beverage</SelectItem>
                        <SelectItem value="fashion">Fashion & Apparel</SelectItem>
                        <SelectItem value="tech">Technology</SelectItem>
                        <SelectItem value="services">Services</SelectItem>
                        <SelectItem value="manufacturing">Manufacturing</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}

              {/* Step 3: Budget & Goals */}
              {currentStep === 3 && (
                <div className="space-y-6">
                  <div className="text-center">
                    <Target className="w-12 h-12 text-accent mx-auto mb-4" />
                    <CardTitle className="text-2xl mb-2">What are your goals?</CardTitle>
                    <CardDescription>This helps us tailor our recommendations</CardDescription>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="budget">Available Budget</Label>
                      <Select
                        value={onboardingData.budget}
                        onValueChange={(value) => setOnboardingData({ ...onboardingData, budget: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select your budget range" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="under-1k">Under $1,000</SelectItem>
                          <SelectItem value="1k-5k">$1,000 - $5,000</SelectItem>
                          <SelectItem value="5k-10k">$5,000 - $10,000</SelectItem>
                          <SelectItem value="10k-25k">$10,000 - $25,000</SelectItem>
                          <SelectItem value="25k-plus">$25,000+</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="goals">Primary Goals</Label>
                      <Textarea
                        id="goals"
                        placeholder="What do you want to achieve? (e.g., launch my first product, scale to 100 customers, expand internationally)"
                        value={onboardingData.goals}
                        onChange={(e) => setOnboardingData({ ...onboardingData, goals: e.target.value })}
                        className="min-h-[100px]"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Step 4: Experience */}
              {currentStep === 4 && (
                <div className="space-y-6">
                  <div className="text-center">
                    <DollarSign className="w-12 h-12 text-accent mx-auto mb-4" />
                    <CardTitle className="text-2xl mb-2">Tell us about your experience</CardTitle>
                    <CardDescription>This helps us provide the right level of guidance</CardDescription>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label>Business Experience Level</Label>
                      <div className="grid grid-cols-1 gap-3 mt-2">
                        {[
                          { value: "beginner", label: "Complete beginner", desc: "First time entrepreneur" },
                          { value: "some", label: "Some experience", desc: "Tried a few things before" },
                          { value: "experienced", label: "Experienced", desc: "Run businesses before" },
                        ].map((exp) => (
                          <Card
                            key={exp.value}
                            className={`cursor-pointer transition-colors ${
                              onboardingData.experience === exp.value ? "border-accent bg-accent/5" : ""
                            }`}
                            onClick={() => setOnboardingData({ ...onboardingData, experience: exp.value })}
                          >
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between">
                                <div>
                                  <h3 className="font-semibold">{exp.label}</h3>
                                  <p className="text-sm text-muted-foreground">{exp.desc}</p>
                                </div>
                                {onboardingData.experience === exp.value && <Badge variant="secondary">Selected</Badge>}
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Navigation */}
              <div className="flex justify-between mt-8">
                <Button variant="outline" onClick={handleBack} disabled={currentStep === 1}>
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
                <Button onClick={handleNext}>
                  {currentStep === 4 ? "Complete Setup" : "Next"}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
