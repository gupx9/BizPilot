"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { AIChatBubble } from "@/components/ai-chat-bubble"
import {
  Plus,
  Lightbulb,
  BarChart3,
  Users,
  DollarSign,
  TrendingUp,
  Clock,
  MapPin,
  Zap,
  LogOut,
  Crown,
  MessageSquare,
  Calendar,
  Filter,
  Search,
  ZoomIn,
  Share2,
  UserPlus,
} from "lucide-react"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
} from "recharts"
import PremiumGate from "@/components/premium-gate" // Declare the PremiumGate variable

const revenueData = [
  { month: "Jan", conservative: 2000, balanced: 3500, aggressive: 8000 },
  { month: "Feb", conservative: 3200, balanced: 5200, aggressive: 12000 },
  { month: "Mar", conservative: 4100, balanced: 6800, aggressive: 15500 },
  { month: "Apr", conservative: 5300, balanced: 8900, aggressive: 19200 },
  { month: "May", conservative: 6800, balanced: 11500, aggressive: 24000 },
  { month: "Jun", conservative: 8200, balanced: 14200, aggressive: 28500 },
]

const costData = [
  { name: "Marketing", value: 35, color: "#8884d8" },
  { name: "Operations", value: 25, color: "#82ca9d" },
  { name: "Staff", value: 20, color: "#ffc658" },
  { name: "Technology", value: 15, color: "#ff7300" },
  { name: "Other", value: 5, color: "#00ff88" },
]

const marketData = [
  { segment: "Young Adults", potential: 45000, captured: 12000 },
  { segment: "Professionals", potential: 32000, captured: 8500 },
  { segment: "Students", potential: 28000, captured: 15000 },
  { segment: "Seniors", potential: 18000, captured: 3200 },
]

export default function DashboardPage() {
  const [userData, setUserData] = useState<any>(null)
  const [ideas, setIdeas] = useState<any[]>([])
  const [selectedModel, setSelectedModel] = useState<string>("conservative")
  const [selectedView, setSelectedView] = useState<string>("overview")
  const [riskFilter, setRiskFilter] = useState<string>("all")
  const [showFeedback, setShowFeedback] = useState(false)
  const [aiModels, setAiModels] = useState<any[]>([])
  const [isGeneratingModels, setIsGeneratingModels] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const user = localStorage.getItem("bizpilot_user")
    if (!user) {
      router.push("/auth/login")
      return
    }

    const parsedUser = JSON.parse(user)
    setUserData(parsedUser)

    const userIdeas = JSON.parse(localStorage.getItem("bizpilot_ideas") || "[]")
    const filteredIdeas = userIdeas.filter((idea: any) => idea.userId === parsedUser.email)
    setIdeas(filteredIdeas)

    if (filteredIdeas.length > 0) {
      generateAIModels(filteredIdeas[0])
    }
  }, [router])

  const generateAIModels = async (idea: any) => {
    if (isGeneratingModels) return

    setIsGeneratingModels(true)
    try {
      const response = await fetch("/api/generate-models", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          idea: idea.description,
          industry: idea.category,
          budget: idea.budget,
          timeline: idea.timeline,
          location: idea.location || "Dhaka, Bangladesh",
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setAiModels(data.models)
      }
    } catch (error) {
      console.error("Failed to generate AI models:", error)
    } finally {
      setIsGeneratingModels(false)
    }
  }

  const businessModels =
    aiModels.length > 0
      ? aiModels.reduce((acc, model) => {
          acc[model.riskLevel] = {
            name: model.name,
            revenue: `৳${model.financials.projectedMonthlyRevenue.toLocaleString()}`,
            timeline: model.marketEntry.timeline,
            risk: model.riskLevel.charAt(0).toUpperCase() + model.riskLevel.slice(1),
            investment: `৳${model.financials.initialInvestment.toLocaleString()}`,
            tasks: model.marketEntry.keySteps,
            description: model.description,
            operations: model.operations,
            risks: model.risks,
            opportunities: model.opportunities,
            sustainabilityScore: model.sustainabilityScore,
          }
          return acc
        }, {} as any)
      : {
          conservative: {
            name: "Conservative Growth",
            revenue: "৳41K",
            timeline: "18 months",
            risk: "Low",
            investment: "৳8K",
            tasks: [
              "Market research and validation",
              "Build MVP with core features",
              "Launch beta with 50 users",
              "Gather feedback and iterate",
              "Scale marketing gradually",
            ],
          },
          aggressive: {
            name: "Aggressive Expansion",
            revenue: "৳125K",
            timeline: "12 months",
            risk: "High",
            investment: "৳25K",
            tasks: [
              "Rapid prototype development",
              "Large-scale marketing campaign",
              "Hire team of 5 specialists",
              "Multi-channel distribution",
              "International market entry",
            ],
          },
          balanced: {
            name: "Balanced Approach",
            revenue: "৳78K",
            timeline: "15 months",
            risk: "Medium",
            investment: "৳15K",
            tasks: [
              "Thorough market analysis",
              "Build solid MVP foundation",
              "Strategic partnership development",
              "Gradual team expansion",
              "Data-driven scaling decisions",
            ],
          },
        }

  const handleLogout = () => {
    localStorage.removeItem("bizpilot_user")
    localStorage.removeItem("bizpilot_ideas")
    router.push("/")
  }

  const handleFeedbackSubmit = (feedback: string) => {
    const existingFeedback = JSON.parse(localStorage.getItem("bizpilot_feedback") || "[]")
    existingFeedback.push({
      id: Date.now(),
      userId: userData.email,
      feedback,
      timestamp: new Date().toISOString(),
      type: "general",
    })
    localStorage.setItem("bizpilot_feedback", JSON.stringify(existingFeedback))
    setShowFeedback(false)
  }

  const handlePremiumRedirect = () => {
    router.push("/premium")
  }

  const filteredModels = Object.entries(businessModels).filter(([key, model]) => {
    if (riskFilter === "all") return true
    return model.risk.toLowerCase() === riskFilter
  })

  if (!userData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">Loading...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-accent-foreground" />
            </div>
            <span className="text-xl font-bold">BizPilot</span>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-muted-foreground">Welcome back, {userData.name}</span>
            <Button variant="outline" size="sm" onClick={() => setShowFeedback(true)}>
              <MessageSquare className="w-4 h-4 mr-2" />
              Feedback
            </Button>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
          <p className="text-muted-foreground">
            {ideas.length === 0
              ? "Ready to turn your ideas into reality? Let's get started!"
              : `You have ${ideas.length} business idea${ideas.length === 1 ? "" : "s"} in development.`}
          </p>
        </div>

        <div className="mb-8">
          <Card className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 border-blue-200 dark:border-blue-800">
            <CardContent className="p-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <h3 className="text-xl font-semibold mb-2 flex items-center">
                    <TrendingUp className="w-6 h-6 mr-2 text-blue-600" />
                    AI-Powered Business Forecasting
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    Get intelligent predictions for demand, production, inventory, and staffing using machine learning
                    with real-time weather, economic, and market data integration.
                  </p>
                </div>
                <div className="flex-shrink-0">
                  <Button
                    onClick={() => router.push("/operations")}
                    size="lg"
                    className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg"
                  >
                    <BarChart3 className="w-5 h-5 mr-2" />
                    Launch Forecasting Center
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {ideas.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mb-8">
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Filter className="w-5 h-5 mr-2" />
                    Model Navigator
                  </CardTitle>
                  <div className="flex items-center space-x-2">
                    <Search className="w-4 h-4 text-muted-foreground" />
                    <input
                      type="text"
                      placeholder="Search models..."
                      className="flex-1 text-sm bg-transparent border-none outline-none"
                    />
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Filter by Risk Level</label>
                    <select
                      value={riskFilter}
                      onChange={(e) => setRiskFilter(e.target.value)}
                      className="w-full p-2 text-sm border rounded-lg bg-background"
                    >
                      <option value="all">All Risk Levels</option>
                      <option value="low">Low Risk</option>
                      <option value="medium">Medium Risk</option>
                      <option value="high">High Risk</option>
                    </select>
                  </div>

                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {filteredModels.map(([key, model]) => (
                      <Card
                        key={key}
                        className={`cursor-pointer transition-all p-3 ${
                          selectedModel === key ? "ring-2 ring-accent bg-accent/5" : "hover:bg-muted/50"
                        }`}
                        onClick={() => setSelectedModel(key)}
                      >
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium text-sm truncate flex-1 mr-2">{model.name}</h4>
                            <Badge
                              variant={
                                model.risk === "Low" ? "secondary" : model.risk === "Medium" ? "default" : "destructive"
                              }
                              className="text-xs flex-shrink-0"
                            >
                              {model.risk}
                            </Badge>
                          </div>
                          <div className="text-xs text-muted-foreground space-y-1">
                            <div className="truncate">Revenue: {model.revenue}</div>
                            <div className="truncate">Timeline: {model.timeline}</div>
                            <div className="truncate">Investment: {model.investment}</div>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>

                  <div className="pt-4 border-t">
                    <label className="text-sm font-medium mb-2 block">View Mode</label>
                    <div className="space-y-1">
                      {["overview", "charts", "simulations", "collaboration"].map((view) => (
                        <button
                          key={view}
                          onClick={() => setSelectedView(view)}
                          className={`w-full text-left p-2 text-sm rounded-lg transition-colors truncate ${
                            selectedView === view ? "bg-accent text-accent-foreground" : "hover:bg-muted"
                          }`}
                        >
                          {view.charAt(0).toUpperCase() + view.slice(1)}
                        </button>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="lg:col-span-3">
              <Card>
                <CardHeader>
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <CardTitle className="flex items-center min-w-0">
                      <BarChart3 className="w-5 h-5 mr-2 flex-shrink-0" />
                      <span className="truncate">
                        {businessModels[selectedModel as keyof typeof businessModels].name} -{" "}
                        {selectedView.charAt(0).toUpperCase() + selectedView.slice(1)}
                      </span>
                    </CardTitle>
                    <div className="flex items-center space-x-2 flex-shrink-0">
                     
                      <Button variant="outline" size="sm" onClick={handlePremiumRedirect}>
                        <Share2 className="w-4 h-4 mr-2" />
                        Share
                        <Crown className="w-3 h-3 ml-1" />
                      </Button>
                      <Button variant="outline" size="sm" onClick={handlePremiumRedirect}>
                        <UserPlus className="w-4 h-4 mr-2" />
                        Collaborate
                        <Crown className="w-3 h-3 ml-1" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {selectedView === "overview" && (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                        <div className="min-w-0">
                          <h4 className="font-semibold mb-3">Revenue Projection</h4>
                          <div className="w-full h-[200px]">
                            <ResponsiveContainer width="100%" height="100%">
                              <LineChart data={revenueData}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="month" />
                                <YAxis />
                                <Tooltip />
                                <Line type="monotone" dataKey={selectedModel} stroke="#8884d8" strokeWidth={3} />
                              </LineChart>
                            </ResponsiveContainer>
                          </div>
                        </div>
                        <div className="min-w-0">
                          <h4 className="font-semibold mb-3">Cost Breakdown</h4>
                          <div className="w-full h-[200px]">
                            <ResponsiveContainer width="100%" height="100%">
                              <PieChart>
                                <Pie
                                  data={getCostDataForModel(selectedModel)}
                                  cx="50%"
                                  cy="50%"
                                  outerRadius={80}
                                  fill="#8884d8"
                                  dataKey="value"
                                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                                >
                                  {getCostDataForModel(selectedModel).map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                  ))}
                                </Pie>
                                <Tooltip />
                              </PieChart>
                            </ResponsiveContainer>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedView === "charts" && (
                    <div className="space-y-6">
                      <div className="min-w-0">
                        <h4 className="font-semibold mb-3">Revenue Curves Comparison</h4>
                        <div className="w-full h-[300px]">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={revenueData}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="month" />
                              <YAxis />
                              <Tooltip />
                              <Line type="monotone" dataKey="conservative" stroke="#82ca9d" name="Conservative" />
                              <Line type="monotone" dataKey="balanced" stroke="#8884d8" name="Balanced" />
                              <Line type="monotone" dataKey="aggressive" stroke="#ffc658" name="Aggressive" />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                      <div className="min-w-0">
                        <h4 className="font-semibold mb-3">Market Penetration Analysis</h4>
                        <div className="w-full h-[250px]">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={marketData}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="segment" />
                              <YAxis />
                              <Tooltip />
                              <Bar dataKey="potential" fill="#e0e0e0" name="Market Potential" />
                              <Bar dataKey="captured" fill="#8884d8" name="Captured Market" />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedView === "simulations" && (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Interactive Simulation</CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-4">
                            <div>
                              <label className="text-sm font-medium">Marketing Budget: $5,000</label>
                              <input type="range" min="1000" max="20000" defaultValue="5000" className="w-full mt-2" />
                            </div>
                            <div>
                              <label className="text-sm font-medium">Team Size: 3 people</label>
                              <input type="range" min="1" max="10" defaultValue="3" className="w-full mt-2" />
                            </div>
                            <div>
                              <label className="text-sm font-medium">Launch Timeline: 6 months</label>
                              <input type="range" min="3" max="24" defaultValue="6" className="w-full mt-2" />
                            </div>
                            <Button className="w-full" onClick={handlePremiumRedirect}>
                              Run Advanced Simulation
                              <Crown className="w-4 h-4 ml-2" />
                            </Button>
                          </CardContent>
                        </Card>
                        <div className="min-w-0">
                          <h4 className="font-semibold mb-3">Simulation Results</h4>
                          <div className="w-full h-[200px]">
                            <ResponsiveContainer width="100%" height="100%">
                              <LineChart data={revenueData}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="month" />
                                <YAxis />
                                <Tooltip />
                                <Line type="monotone" dataKey="balanced" stroke="#8884d8" strokeWidth={3} />
                              </LineChart>
                            </ResponsiveContainer>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedView === "collaboration" && (
                    <div className="space-y-6">
                      <div className="text-center py-8">
                        <UserPlus className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                        <h3 className="text-xl font-semibold mb-2">Collaboration Features</h3>
                        <p className="text-muted-foreground mb-6">
                          Invite team members, share models, and collaborate in real-time
                        </p>
                        <Button onClick={handlePremiumRedirect}>
                          <Crown className="w-4 h-4 mr-2" />
                          Upgrade to Access Collaboration
                        </Button>
                      </div>
                    </div>
                  )}

                  <Card className="mt-6">
                    <CardHeader>
                      <CardTitle className="text-lg">
                        Auto-Generated Action Plan: {businessModels[selectedModel as keyof typeof businessModels].name}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {businessModels[selectedModel as keyof typeof businessModels].tasks.map((task, index) => (
                          <div key={index} className="flex items-center space-x-3">
                            <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center text-sm font-medium">
                              {index + 1}
                            </div>
                            <span className="text-sm">{task}</span>
                          </div>
                        ))}
                      </div>
                      <Button
                        className="mt-4 w-full"
                        onClick={() => {
                          localStorage.setItem(
                            "bizpilot_selected_model",
                            JSON.stringify({
                              model: selectedModel,
                              data: businessModels[selectedModel as keyof typeof businessModels],
                            }),
                          )
                          router.push("/ideas/create")
                        }}
                      >
                        Start This Business Model
                      </Button>
                    </CardContent>
                  </Card>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Ideas</p>
                  <p className="text-2xl font-bold">{ideas.length}</p>
                </div>
                <Lightbulb className="w-8 h-8 text-accent" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">In Progress</p>
                  <p className="text-2xl font-bold">{ideas.filter((idea) => idea.status === "draft").length}</p>
                </div>
                <Clock className="w-8 h-8 text-accent" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">AI Messages</p>
                  <p className="text-2xl font-bold">47/50</p>
                </div>
                <BarChart3 className="w-8 h-8 text-accent" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Plan</p>
                  <p className="text-2xl font-bold">Free</p>
                </div>
                <TrendingUp className="w-8 h-8 text-accent" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Your Ideas</h2>
              <Button onClick={() => router.push("/ideas/create")}>
                <Plus className="w-4 h-4 mr-2" />
                New Idea
              </Button>
            </div>

            {ideas.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Lightbulb className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No ideas yet</h3>
                  <p className="text-muted-foreground mb-6">
                    Start your entrepreneurial journey by creating your first business idea
                  </p>
                  <Button onClick={() => router.push("/ideas/create")}>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Your First Idea
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {ideas.map((idea) => (
                  <Card key={idea.id} className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold mb-2">{idea.title}</h3>
                          <p className="text-muted-foreground text-sm line-clamp-2 mb-3">{idea.description}</p>
                          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                            {idea.category && <Badge variant="secondary">{idea.category}</Badge>}
                            {idea.location && (
                              <div className="flex items-center">
                                <MapPin className="w-3 h-3 mr-1" />
                                {idea.location}
                              </div>
                            )}
                            {idea.budget && (
                              <div className="flex items-center">
                                <DollarSign className="w-3 h-3 mr-1" />
                                {idea.budget}
                              </div>
                            )}
                          </div>
                        </div>
                        <Badge variant={idea.status === "draft" ? "secondary" : "default"}>{idea.status}</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="text-xs text-muted-foreground">
                          Created {new Date(idea.createdAt).toLocaleDateString()}
                        </div>
                        <Button variant="outline" size="sm" onClick={() => router.push(`/ideas/${idea.id}`)}>
                          View Details
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">6-Month Roadmap Templates</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  variant="outline"
                  className="w-full justify-start bg-transparent"
                  onClick={handlePremiumRedirect}
                >
                  <Calendar className="w-4 h-4 mr-2 flex-shrink-0" />
                  <span className="truncate">E-commerce Launch</span>
                  <Badge variant="secondary" className="ml-auto flex-shrink-0">
                    <Crown className="w-3 h-3" />
                  </Badge>
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start bg-transparent"
                  onClick={handlePremiumRedirect}
                >
                  <Calendar className="w-4 h-4 mr-2 flex-shrink-0" />
                  <span className="truncate">SaaS Product Development</span>
                  <Badge variant="secondary" className="ml-auto flex-shrink-0">
                    <Crown className="w-3 h-3" />
                  </Badge>
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start bg-transparent"
                  onClick={handlePremiumRedirect}
                >
                  <Calendar className="w-4 h-4 mr-2 flex-shrink-0" />
                  <span className="truncate">Local Service Business</span>
                  <Badge variant="secondary" className="ml-auto flex-shrink-0">
                    <Crown className="w-3 h-3" />
                  </Badge>
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start bg-transparent"
                  onClick={handlePremiumRedirect}
                >
                  <Calendar className="w-4 h-4 mr-2 flex-shrink-0" />
                  <span className="truncate">Content Creator Business</span>
                  <Badge variant="secondary" className="ml-auto flex-shrink-0">
                    <Crown className="w-3 h-3" />
                  </Badge>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Market Opportunity Alerts</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-sm space-y-2">
                  <div className="flex items-center justify-between">
                    <span>Trending Products</span>
                    <Badge variant="secondary">Active</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Price Changes</span>
                    <Badge variant="secondary">Active</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>New Competitors</span>
                    <Badge variant="outline">Inactive</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Market Trends</span>
                    <Badge variant="outline">Pro Only</Badge>
                  </div>
                </div>
                <Button variant="outline" className="w-full bg-transparent">
                  Configure Alerts
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  variant="outline"
                  className="w-full justify-start bg-transparent"
                  onClick={handlePremiumRedirect}
                >
                  <Lightbulb className="w-4 h-4 mr-2 flex-shrink-0" />
                  <span className="truncate">AI Business Coach</span>
                  <Badge variant="secondary" className="ml-auto flex-shrink-0">
                    <Crown className="w-3 h-3" />
                  </Badge>
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  <BarChart3 className="w-4 h-4 mr-2 flex-shrink-0" />
                  <span className="truncate">Market Analysis</span>
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start bg-transparent"
                  onClick={handlePremiumRedirect}
                >
                  <Users className="w-4 h-4 mr-2 flex-shrink-0" />
                  <span className="truncate">Find Co-founders</span>
                  <Badge variant="secondary" className="ml-auto flex-shrink-0">
                    <Crown className="w-3 h-3" />
                  </Badge>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Usage This Month</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>AI Messages</span>
                    <span>47/50</span>
                  </div>
                  <Progress value={94} />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Business Models</span>
                    <span>3/6</span>
                  </div>
                  <Progress value={50} />
                </div>
                <Button variant="outline" className="w-full bg-transparent" onClick={handlePremiumRedirect}>
                  <Crown className="w-4 h-4 mr-2" />
                  Upgrade to Pro
                </Button>
              </CardContent>
            </Card>

            <PremiumGate
              feature="Premium Dashboard"
              description="Access advanced analytics, unlimited AI messages, and priority support."
            >
              <div className="space-y-3">
                <div className="text-sm space-y-2">
                  <div className="flex items-center text-muted-foreground">
                    <div className="w-2 h-2 bg-accent rounded-full mr-2"></div>
                    Advanced AI simulations
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <div className="w-2 h-2 bg-accent rounded-full mr-2"></div>
                    24-month forecasts
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <div className="w-2 h-2 bg-accent rounded-full mr-2"></div>
                    Competitor analysis
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <div className="w-2 h-2 bg-accent rounded-full mr-2"></div>
                    Export capabilities
                  </div>
                </div>
              </div>
            </PremiumGate>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-accent rounded-full"></div>
                    <span>Account created</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-muted rounded-full"></div>
                    <span>Completed onboarding</span>
                  </div>
                  {ideas.length > 0 && (
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-accent rounded-full"></div>
                      <span>Created first idea</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {ideas.length > 0 && (
          <div className="mb-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2" />
                  Data Integration Hub
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Upload your business data for AI-powered insights and forecasting
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="p-4">
                    <h4 className="font-medium mb-2 truncate">Sales Data</h4>
                    <p className="text-sm text-muted-foreground mb-3">Upload CSV/Excel files</p>
                    <Button variant="outline" className="w-full bg-transparent" onClick={handlePremiumRedirect}>
                      <Crown className="w-4 h-4 mr-2 flex-shrink-0" />
                      <span className="truncate">Upload Sales Data</span>
                    </Button>
                  </Card>
                  <Card className="p-4">
                    <h4 className="font-medium mb-2 truncate">Inventory Photos</h4>
                    <p className="text-sm text-muted-foreground mb-3">AI image analysis</p>
                    <Button variant="outline" className="w-full bg-transparent" onClick={handlePremiumRedirect}>
                      <Crown className="w-4 h-4 mr-2 flex-shrink-0" />
                      <span className="truncate">Analyze Images</span>
                    </Button>
                  </Card>
                  <Card className="p-4">
                    <h4 className="font-medium mb-2 truncate">Market Data</h4>
                    <p className="text-sm text-muted-foreground mb-3">External API integration</p>
                    <Button variant="outline" className="w-full bg-transparent" onClick={handlePremiumRedirect}>
                      <Crown className="w-4 h-4 mr-2 flex-shrink-0" />
                      <span className="truncate">Connect APIs</span>
                    </Button>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      <AIChatBubble />
    </div>
  )
}

function getCostDataForModel(model: string) {
  const costDataVariants = {
    conservative: [
      { name: "Marketing", value: 25, color: "#8884d8" },
      { name: "Operations", value: 35, color: "#82ca9d" },
      { name: "Staff", value: 15, color: "#ffc658" },
      { name: "Technology", value: 20, color: "#ff7300" },
      { name: "Other", value: 5, color: "#00ff88" },
    ],
    balanced: [
      { name: "Marketing", value: 35, color: "#8884d8" },
      { name: "Operations", value: 25, color: "#82ca9d" },
      { name: "Staff", value: 20, color: "#ffc658" },
      { name: "Technology", value: 15, color: "#ff7300" },
      { name: "Other", value: 5, color: "#00ff88" },
    ],
    aggressive: [
      { name: "Marketing", value: 45, color: "#8884d8" },
      { name: "Operations", value: 20, color: "#82ca9d" },
      { name: "Staff", value: 25, color: "#ffc658" },
      { name: "Technology", value: 8, color: "#ff7300" },
      { name: "Other", value: 2, color: "#00ff88" },
    ],
  }
  return costDataVariants[model as keyof typeof costDataVariants] || costDataVariants.balanced
}
