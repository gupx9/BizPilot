"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Crown, Zap, BarChart3, TrendingUp, Users, Globe, Sparkles, ArrowRight, Check, X, Lock } from "lucide-react"

export default function PremiumPage() {
  const [userData, setUserData] = useState<any>(null)
  const [selectedPlan, setSelectedPlan] = useState("pro")
  const [isAnnual, setIsAnnual] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const user = localStorage.getItem("bizpilot_user")
    if (!user) {
      router.push("/auth/login")
      return
    }
    setUserData(JSON.parse(user))
  }, [router])

  const plans = {
    free: {
      name: "Free",
      price: { monthly: 0, annual: 0 },
      description: "Perfect for getting started",
      features: [
        { name: "2 business models per idea", included: true },
        { name: "3-month forecasts", included: true },
        { name: "50 AI messages/month", included: true },
        { name: "Basic charts & analytics", included: true },
        { name: "Community support", included: true },
        { name: "Advanced simulations", included: false },
        { name: "24-month forecasts", included: false },
        { name: "Unlimited AI messages", included: false },
        { name: "Export capabilities", included: false },
        { name: "Priority support", included: false },
      ],
    },
    pro: {
      name: "Pro",
      price: { monthly: 9.99, annual: 99.99 },
      description: "For serious entrepreneurs",
      popular: true,
      features: [
        { name: "Unlimited business models", included: true },
        { name: "24-month advanced forecasts", included: true },
        { name: "Unlimited AI messages", included: true },
        { name: "Advanced simulations", included: true },
        { name: "Export to PDF/Excel", included: true },
        { name: "Competitor analysis", included: true },
        { name: "Market trend alerts", included: true },
        { name: "Priority support", included: true },
        { name: "API access", included: false },
        { name: "White-label branding", included: false },
      ],
    },
    enterprise: {
      name: "Enterprise",
      price: { monthly: 49.99, annual: 499.99 },
      description: "For teams and organizations",
      features: [
        { name: "Everything in Pro", included: true },
        { name: "Team collaboration", included: true },
        { name: "White-label branding", included: true },
        { name: "API access", included: true },
        { name: "Custom AI fine-tuning", included: true },
        { name: "Dedicated account manager", included: true },
        { name: "SLA guarantee", included: true },
        { name: "Analytics exports", included: true },
        { name: "Custom integrations", included: true },
        { name: "Advanced security", included: true },
      ],
    },
  }

  if (!userData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">Loading...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-accent-foreground" />
            </div>
            <span className="text-xl font-bold">BizPilot</span>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="sm" onClick={() => router.push("/dashboard")}>
              Back to Dashboard
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Crown className="w-12 h-12 text-accent mr-3" />
            <h1 className="text-4xl font-bold">Upgrade to Premium</h1>
          </div>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Unlock advanced AI simulations, unlimited forecasts, and powerful business intelligence tools
          </p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center space-x-4 mb-8">
            <span className={`text-sm ${!isAnnual ? "font-semibold" : "text-muted-foreground"}`}>Monthly</span>
            <Switch checked={isAnnual} onCheckedChange={setIsAnnual} />
            <span className={`text-sm ${isAnnual ? "font-semibold" : "text-muted-foreground"}`}>
              Annual
              <Badge variant="secondary" className="ml-2">
                Save 17%
              </Badge>
            </span>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {Object.entries(plans).map(([key, plan]) => (
            <Card
              key={key}
              className={`relative ${
                plan.popular ? "border-accent shadow-lg scale-105" : ""
              } ${selectedPlan === key ? "ring-2 ring-accent" : ""}`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-accent text-accent-foreground">Most Popular</Badge>
                </div>
              )}
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <div className="text-4xl font-bold mb-2">
                  ${isAnnual ? plan.price.annual : plan.price.monthly}
                  <span className="text-lg text-muted-foreground">
                    {plan.price.monthly === 0 ? "" : isAnnual ? "/year" : "/month"}
                  </span>
                </div>
                <p className="text-muted-foreground">{plan.description}</p>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-sm">
                      {feature.included ? (
                        <Check className="w-4 h-4 text-green-600 mr-3 flex-shrink-0" />
                      ) : (
                        <X className="w-4 h-4 text-muted-foreground mr-3 flex-shrink-0" />
                      )}
                      <span className={feature.included ? "" : "text-muted-foreground"}>{feature.name}</span>
                    </li>
                  ))}
                </ul>
                <Button
                  className="w-full"
                  variant={key === "free" ? "outline" : selectedPlan === key ? "default" : "outline"}
                  onClick={() => setSelectedPlan(key)}
                >
                  {key === "free" ? "Current Plan" : selectedPlan === key ? "Selected" : "Select Plan"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Premium Features Showcase */}
        <Tabs defaultValue="simulations" className="mb-12">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="simulations">Advanced Simulations</TabsTrigger>
            <TabsTrigger value="ai-coach">AI Business Coach</TabsTrigger>
            <TabsTrigger value="analytics">Deep Analytics</TabsTrigger>
            <TabsTrigger value="collaboration">Team Features</TabsTrigger>
          </TabsList>

          <TabsContent value="simulations" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2" />
                  Monte Carlo Risk Assessment
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-4">Scenario Parameters</h4>
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium mb-2 block">Market Volatility</label>
                        <Slider defaultValue={[30]} max={100} step={1} className="mb-2" />
                        <div className="text-sm text-muted-foreground">30% volatility</div>
                      </div>
                      <div>
                        <label className="text-sm font-medium mb-2 block">Competition Impact</label>
                        <Slider defaultValue={[45]} max={100} step={1} className="mb-2" />
                        <div className="text-sm text-muted-foreground">45% impact factor</div>
                      </div>
                      <div>
                        <label className="text-sm font-medium mb-2 block">Economic Conditions</label>
                        <Slider defaultValue={[60]} max={100} step={1} className="mb-2" />
                        <div className="text-sm text-muted-foreground">60% favorable</div>
                      </div>
                    </div>
                  </div>
                  <div className="bg-muted/50 rounded-lg p-6">
                    <h4 className="font-semibold mb-4">Simulation Results</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span>Best Case Scenario</span>
                        <span className="font-bold text-green-600">$125,000</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Most Likely Outcome</span>
                        <span className="font-bold">$78,000</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Worst Case Scenario</span>
                        <span className="font-bold text-red-600">$32,000</span>
                      </div>
                      <div className="flex justify-between pt-3 border-t">
                        <span>Success Probability</span>
                        <span className="font-bold text-accent">73%</span>
                      </div>
                    </div>
                    <div className="mt-4 p-3 bg-accent/10 rounded-lg">
                      <div className="flex items-center">
                        <Lock className="w-4 h-4 mr-2 text-accent" />
                        <span className="text-sm font-medium">Premium Feature</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ai-coach" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Sparkles className="w-5 h-5 mr-2" />
                  AI Business Coach Chat
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-muted/30 rounded-lg p-4 h-96 overflow-y-auto mb-4">
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                        <Sparkles className="w-4 h-4 text-accent-foreground" />
                      </div>
                      <div className="bg-background rounded-lg p-3 max-w-xs">
                        <p className="text-sm">
                          Hello! I'm your AI Business Coach. I've analyzed your eco-friendly shoe brand idea. Would you
                          like me to suggest some market entry strategies?
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3 justify-end">
                      <div className="bg-accent rounded-lg p-3 max-w-xs">
                        <p className="text-sm text-accent-foreground">
                          Yes, I'd love to hear your suggestions for entering the Dhaka market.
                        </p>
                      </div>
                      <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                        <Users className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                        <Sparkles className="w-4 h-4 text-accent-foreground" />
                      </div>
                      <div className="bg-background rounded-lg p-3 max-w-md">
                        <p className="text-sm">
                          Based on market analysis, I recommend starting with university campuses and young professional
                          areas. Here's a 3-phase launch strategy:
                        </p>
                        <ul className="text-sm mt-2 space-y-1">
                          <li>• Phase 1: Partner with 3 universities for student discounts</li>
                          <li>• Phase 2: Pop-up stores in Gulshan and Dhanmondi</li>
                          <li>• Phase 3: Online marketplace expansion</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    placeholder="Ask your AI coach anything..."
                    className="flex-1 px-3 py-2 border rounded-lg bg-background"
                    disabled
                  />
                  <Button disabled>
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </div>
                <div className="mt-4 p-3 bg-accent/10 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Lock className="w-4 h-4 mr-2 text-accent" />
                      <span className="text-sm font-medium">Unlock unlimited AI coaching</span>
                    </div>
                    <Button size="sm">Upgrade</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2" />
                    Market Trend Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-950 rounded-lg">
                      <div>
                        <p className="font-medium text-green-800 dark:text-green-200">Sustainable Fashion</p>
                        <p className="text-sm text-green-600 dark:text-green-400">Growing 23% YoY</p>
                      </div>
                      <TrendingUp className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                      <div>
                        <p className="font-medium text-blue-800 dark:text-blue-200">E-commerce Adoption</p>
                        <p className="text-sm text-blue-600 dark:text-blue-400">Up 45% in Bangladesh</p>
                      </div>
                      <TrendingUp className="w-5 h-5 text-blue-600" />
                    </div>
                    <div className="flex items-center justify-between p-3 bg-orange-50 dark:bg-orange-950 rounded-lg">
                      <div>
                        <p className="font-medium text-orange-800 dark:text-orange-200">Youth Spending Power</p>
                        <p className="text-sm text-orange-600 dark:text-orange-400">Increasing 12% annually</p>
                      </div>
                      <TrendingUp className="w-5 h-5 text-orange-600" />
                    </div>
                  </div>
                  <div className="mt-4 p-3 bg-accent/10 rounded-lg">
                    <div className="flex items-center">
                      <Lock className="w-4 h-4 mr-2 text-accent" />
                      <span className="text-sm font-medium">Real-time market alerts</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Globe className="w-5 h-5 mr-2" />
                    Export Capabilities
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button variant="outline" className="w-full justify-start bg-transparent" disabled>
                      <div className="w-4 h-4 mr-2 bg-red-500 rounded"></div>
                      Export to PDF Report
                    </Button>
                    <Button variant="outline" className="w-full justify-start bg-transparent" disabled>
                      <div className="w-4 h-4 mr-2 bg-green-500 rounded"></div>
                      Export to Excel
                    </Button>
                    <Button variant="outline" className="w-full justify-start bg-transparent" disabled>
                      <div className="w-4 h-4 mr-2 bg-blue-500 rounded"></div>
                      Share with Investors
                    </Button>
                    <Button variant="outline" className="w-full justify-start bg-transparent" disabled>
                      <div className="w-4 h-4 mr-2 bg-purple-500 rounded"></div>
                      API Integration
                    </Button>
                  </div>
                  <div className="mt-4 p-3 bg-accent/10 rounded-lg">
                    <div className="flex items-center">
                      <Lock className="w-4 h-4 mr-2 text-accent" />
                      <span className="text-sm font-medium">Professional export formats</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="collaboration" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="w-5 h-5 mr-2" />
                  Team Collaboration
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-4">Team Members</h4>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3 p-3 border rounded-lg">
                        <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                          <Users className="w-4 h-4 text-accent-foreground" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">Ryan Ahmed</p>
                          <p className="text-sm text-muted-foreground">Co-founder & CTO</p>
                        </div>
                        <Badge variant="secondary">Owner</Badge>
                      </div>
                      <div className="flex items-center space-x-3 p-3 border rounded-lg">
                        <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                          <Users className="w-4 h-4" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">Ahmed Reaz Ashrafi</p>
                          <p className="text-sm text-muted-foreground">Marketing Lead</p>
                        </div>
                        <Badge variant="outline">Editor</Badge>
                      </div>
                      <div className="flex items-center space-x-3 p-3 border rounded-lg">
                        <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                          <Users className="w-4 h-4" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">Muhtasim Faiyaz</p>
                          <p className="text-sm text-muted-foreground">Financial Advisor</p>
                        </div>
                        <Badge variant="outline">Viewer</Badge>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-4">Collaboration Features</h4>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm">Real-time editing</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        <span className="text-sm">Comment & feedback system</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                        <span className="text-sm">Version history</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                        <span className="text-sm">Role-based permissions</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                        <span className="text-sm">Activity notifications</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="mt-6 p-3 bg-accent/10 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Lock className="w-4 h-4 mr-2 text-accent" />
                      <span className="text-sm font-medium">Enterprise team features</span>
                    </div>
                    <Button size="sm">Upgrade</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* CTA Section */}
        <Card className="bg-gradient-to-r from-accent/10 to-accent/5 border-accent/20">
          <CardContent className="p-8 text-center">
            <Crown className="w-16 h-16 text-accent mx-auto mb-4" />
            <h2 className="text-3xl font-bold mb-4">Ready to supercharge your business?</h2>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Join thousands of entrepreneurs who have transformed their ideas into successful businesses with BizPilot
              Pro.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="text-lg px-8">
                <Crown className="w-5 h-5 mr-2" />
                Start Free Trial
              </Button>
              <Button variant="outline" size="lg" className="text-lg px-8 bg-transparent">
                Schedule Demo
              </Button>
            </div>
            <p className="text-sm text-muted-foreground mt-4">14-day free trial • No credit card required</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
