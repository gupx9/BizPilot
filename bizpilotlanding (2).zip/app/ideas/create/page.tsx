"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, ArrowLeft, Mic, MicOff, Upload, Lightbulb, MapPin, Target, Zap, Info } from "lucide-react"

interface IdeaData {
  title: string
  description: string
  category: string
  location: string
  budget: string
  targetMarket: string
  timeline: string
  experience: string
  additionalNotes: string
  selectedModel?: string
  modelData?: any
}

export default function CreateIdeaPage() {
  const [currentStep, setCurrentStep] = useState(1)
  const [isRecording, setIsRecording] = useState(false)
  const [isProcessingVoice, setIsProcessingVoice] = useState(false)
  const [userData, setUserData] = useState<any>(null)
  const [selectedModelInfo, setSelectedModelInfo] = useState<any>(null)
  const [ideaData, setIdeaData] = useState<IdeaData>({
    title: "",
    description: "",
    category: "",
    location: "",
    budget: "",
    targetMarket: "",
    timeline: "",
    experience: "",
    additionalNotes: "",
  })

  const recognitionRef = useRef<any>(null)
  const router = useRouter()

  useEffect(() => {
    // Check authentication
    const user = localStorage.getItem("bizpilot_user")
    if (!user) {
      router.push("/auth/login")
      return
    }
    const parsedUser = JSON.parse(user)
    setUserData(parsedUser)

    const selectedModel = localStorage.getItem("bizpilot_selected_model")
    if (selectedModel) {
      const modelInfo = JSON.parse(selectedModel)
      setSelectedModelInfo(modelInfo)

      // Pre-populate form with model data
      setIdeaData((prev) => ({
        ...prev,
        selectedModel: modelInfo.model,
        modelData: modelInfo.data,
        budget: modelInfo.data.investment?.replace("$", "").replace("K", "000")
          ? getBudgetRange(modelInfo.data.investment)
          : prev.budget,
        timeline: getTimelineFromModel(modelInfo.data.timeline),
        description: `Business model: ${modelInfo.data.name}\n\nKey characteristics:\n- Revenue target: ${modelInfo.data.revenue}\n- Timeline: ${modelInfo.data.timeline}\n- Risk level: ${modelInfo.data.risk}\n- Investment needed: ${modelInfo.data.investment}\n\nAction plan:\n${modelInfo.data.tasks?.map((task: string, index: number) => `${index + 1}. ${task}`).join("\n") || ""}\n\nPlease describe your specific business idea that will follow this model:`,
      }))

      // Clear the stored model data after using it
      localStorage.removeItem("bizpilot_selected_model")
    }

    // Pre-fill location from onboarding if available
    if (parsedUser.onboarding?.location) {
      setIdeaData((prev) => ({ ...prev, location: parsedUser.onboarding.location }))
    }
  }, [router])

  const getBudgetRange = (investment: string) => {
    const amount = Number.parseInt(investment.replace(/[^0-9]/g, ""))
    if (amount < 1000) return "under-1k"
    if (amount <= 5000) return "1k-5k"
    if (amount <= 10000) return "5k-10k"
    if (amount <= 25000) return "10k-25k"
    if (amount <= 50000) return "25k-50k"
    return "50k-plus"
  }

  const getTimelineFromModel = (timeline: string) => {
    const months = Number.parseInt(timeline.replace(/[^0-9]/g, ""))
    if (months <= 3) return "1-3-months"
    if (months <= 6) return "3-6-months"
    if (months <= 12) return "6-12-months"
    return "1-year-plus"
  }

  const startVoiceRecording = () => {
    if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition
      recognitionRef.current = new SpeechRecognition()

      recognitionRef.current.continuous = true
      recognitionRef.current.interimResults = true
      recognitionRef.current.lang = "en-US"

      recognitionRef.current.onstart = () => {
        setIsRecording(true)
        console.log("[v0] Voice recording started")
      }

      recognitionRef.current.onresult = (event: any) => {
        let finalTranscript = ""

        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript
          }
        }

        if (finalTranscript) {
          console.log("[v0] Voice transcript:", finalTranscript)

          // Add to description field
          setIdeaData((prev) => ({
            ...prev,
            description: prev.description + (prev.description ? " " : "") + finalTranscript,
          }))

          // Try to extract title if description is long enough and title is empty
          if (!ideaData.title && finalTranscript.length > 20) {
            const words = finalTranscript.trim().split(" ")
            if (words.length >= 3) {
              const potentialTitle = words.slice(0, 6).join(" ")
              setIdeaData((prev) => ({
                ...prev,
                title: potentialTitle,
              }))
            }
          }
        }
      }

      recognitionRef.current.onerror = (event: any) => {
        console.log("[v0] Voice recognition error:", event.error)
        setIsRecording(false)
        setIsProcessingVoice(false)
      }

      recognitionRef.current.onend = () => {
        setIsRecording(false)
        setIsProcessingVoice(false)
        console.log("[v0] Voice recording ended")
      }

      recognitionRef.current.start()
    } else {
      // Fallback for browsers without speech recognition
      alert("Voice input not supported in this browser. Please use text input.")
    }
  }

  const stopVoiceRecording = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop()
    }
    setIsRecording(false)
    setIsProcessingVoice(true)

    // Simulate processing
    setTimeout(() => {
      setIsProcessingVoice(false)
    }, 1000)
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      console.log("[v0] File uploaded:", file.name, file.type)

      // Demo: simulate file processing
      if (file.type.includes("image")) {
        setIdeaData((prev) => ({
          ...prev,
          additionalNotes: prev.additionalNotes + `\n[Image uploaded: ${file.name}]`,
        }))
      } else if (file.type.includes("pdf") || file.type.includes("document")) {
        setIdeaData((prev) => ({
          ...prev,
          additionalNotes: prev.additionalNotes + `\n[Document uploaded: ${file.name}]`,
        }))
      }
    }
  }

  const handleNext = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1)
    } else {
      // Save idea and redirect to dashboard
      const newIdea = {
        id: Date.now().toString(),
        ...ideaData,
        createdAt: new Date().toISOString(),
        status: "draft",
        userId: userData.email,
      }

      // Save to localStorage (demo)
      const existingIdeas = JSON.parse(localStorage.getItem("bizpilot_ideas") || "[]")
      existingIdeas.push(newIdea)
      localStorage.setItem("bizpilot_ideas", JSON.stringify(existingIdeas))

      console.log("[v0] Idea saved:", newIdea)
      router.push("/dashboard")
    }
  }

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const progress = (currentStep / 3) * 100

  if (!userData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">Loading...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-accent-foreground" />
            </div>
            <span className="text-xl font-bold">BizPilot</span>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-muted-foreground">Welcome, {userData.name}</span>
            <Button variant="outline" size="sm" onClick={() => router.push("/dashboard")}>
              Dashboard
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          {/* Progress Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Lightbulb className="w-8 h-8 text-accent" />
              <h1 className="text-3xl font-bold">Create Your Business Idea</h1>
            </div>
            <p className="text-muted-foreground mb-4">
              Tell us about your business concept and we'll help you develop it
            </p>
            <div className="max-w-md mx-auto">
              <Progress value={progress} className="w-full" />
              <p className="text-sm text-muted-foreground mt-2">Step {currentStep} of 3</p>
            </div>
          </div>

          {selectedModelInfo && (
            <Card className="mb-6 border-accent/20 bg-accent/5">
              <CardContent className="p-4">
                <div className="flex items-start space-x-3">
                  <Info className="w-5 h-5 text-accent mt-0.5" />
                  <div className="flex-1">
                    <h4 className="font-semibold text-accent mb-1">
                      Selected Business Model: {selectedModelInfo.data.name}
                    </h4>
                    <div className="flex flex-wrap gap-2 text-sm">
                      <Badge variant="secondary">Revenue: {selectedModelInfo.data.revenue}</Badge>
                      <Badge variant="secondary">Timeline: {selectedModelInfo.data.timeline}</Badge>
                      <Badge variant="secondary">Risk: {selectedModelInfo.data.risk}</Badge>
                      <Badge variant="secondary">Investment: {selectedModelInfo.data.investment}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">
                      Your form has been pre-populated with this model's parameters. Customize as needed for your
                      specific idea.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardContent className="p-6">
              {/* Step 1: Basic Idea */}
              {currentStep === 1 && (
                <div className="space-y-6">
                  <div className="text-center">
                    <Lightbulb className="w-12 h-12 text-accent mx-auto mb-4" />
                    <CardTitle className="text-2xl mb-2">What's your business idea?</CardTitle>
                    <CardDescription>
                      Describe your concept in detail. You can type, speak, or upload files.
                    </CardDescription>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="title">Business Title/Name</Label>
                      <Input
                        id="title"
                        placeholder="e.g., Eco-Friendly Shoe Brand"
                        value={ideaData.title}
                        onChange={(e) => setIdeaData({ ...ideaData, title: e.target.value })}
                      />
                    </div>

                    <div>
                      <Label htmlFor="description">Detailed Description</Label>
                      <Textarea
                        id="description"
                        placeholder="Describe your business idea in detail... What problem does it solve? Who is your target customer? What makes it unique?"
                        value={ideaData.description}
                        onChange={(e) => setIdeaData({ ...ideaData, description: e.target.value })}
                        className="min-h-[150px]"
                      />
                    </div>

                    {/* Voice Input Controls */}
                    <div className="flex flex-col sm:flex-row gap-3">
                      <Button
                        variant={isRecording ? "destructive" : "outline"}
                        onClick={isRecording ? stopVoiceRecording : startVoiceRecording}
                        disabled={isProcessingVoice}
                        className="flex-1"
                      >
                        {isRecording ? (
                          <>
                            <MicOff className="w-4 h-4 mr-2" />
                            Stop Recording
                          </>
                        ) : isProcessingVoice ? (
                          <>
                            <Mic className="w-4 h-4 mr-2 animate-pulse" />
                            Processing...
                          </>
                        ) : (
                          <>
                            <Mic className="w-4 h-4 mr-2" />
                            Voice Input
                          </>
                        )}
                      </Button>

                      <div className="flex-1">
                        <input
                          type="file"
                          id="file-upload"
                          className="hidden"
                          accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png"
                          onChange={handleFileUpload}
                        />
                        <Button
                          variant="outline"
                          onClick={() => document.getElementById("file-upload")?.click()}
                          className="w-full"
                        >
                          <Upload className="w-4 h-4 mr-2" />
                          Upload File
                        </Button>
                      </div>
                    </div>

                    {isRecording && (
                      <div className="bg-accent/10 border border-accent/20 rounded-lg p-4">
                        <div className="flex items-center space-x-2">
                          <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                          <span className="text-sm font-medium">
                            Recording... Speak clearly about your business idea
                          </span>
                        </div>
                      </div>
                    )}

                    <div>
                      <Label htmlFor="category">Business Category</Label>
                      <Select
                        value={ideaData.category}
                        onValueChange={(value) => setIdeaData({ ...ideaData, category: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select a category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ecommerce">E-commerce</SelectItem>
                          <SelectItem value="food-beverage">Food & Beverage</SelectItem>
                          <SelectItem value="fashion">Fashion & Apparel</SelectItem>
                          <SelectItem value="technology">Technology</SelectItem>
                          <SelectItem value="services">Services</SelectItem>
                          <SelectItem value="manufacturing">Manufacturing</SelectItem>
                          <SelectItem value="health-wellness">Health & Wellness</SelectItem>
                          <SelectItem value="education">Education</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 2: Market & Location */}
              {currentStep === 2 && (
                <div className="space-y-6">
                  <div className="text-center">
                    <MapPin className="w-12 h-12 text-accent mx-auto mb-4" />
                    <CardTitle className="text-2xl mb-2">Market & Location Details</CardTitle>
                    <CardDescription>Help us understand your target market and operational location</CardDescription>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="location">Primary Location</Label>
                      <Input
                        id="location"
                        placeholder="e.g., Dhaka, Bangladesh"
                        value={ideaData.location}
                        onChange={(e) => setIdeaData({ ...ideaData, location: e.target.value })}
                      />
                    </div>

                    <div>
                      <Label htmlFor="targetMarket">Target Market</Label>
                      <Textarea
                        id="targetMarket"
                        placeholder="Who are your ideal customers? Demographics, interests, pain points..."
                        value={ideaData.targetMarket}
                        onChange={(e) => setIdeaData({ ...ideaData, targetMarket: e.target.value })}
                        className="min-h-[100px]"
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="budget">Initial Budget</Label>
                        <Select
                          value={ideaData.budget}
                          onValueChange={(value) => setIdeaData({ ...ideaData, budget: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select budget range" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="under-1k">Under $1,000</SelectItem>
                            <SelectItem value="1k-5k">$1,000 - $5,000</SelectItem>
                            <SelectItem value="5k-10k">$5,000 - $10,000</SelectItem>
                            <SelectItem value="10k-25k">$10,000 - $25,000</SelectItem>
                            <SelectItem value="25k-50k">$25,000 - $50,000</SelectItem>
                            <SelectItem value="50k-plus">$50,000+</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="timeline">Launch Timeline</Label>
                        <Select
                          value={ideaData.timeline}
                          onValueChange={(value) => setIdeaData({ ...ideaData, timeline: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="When do you want to launch?" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1-3-months">1-3 months</SelectItem>
                            <SelectItem value="3-6-months">3-6 months</SelectItem>
                            <SelectItem value="6-12-months">6-12 months</SelectItem>
                            <SelectItem value="1-year-plus">1+ years</SelectItem>
                            <SelectItem value="flexible">Flexible</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 3: Experience & Additional Info */}
              {currentStep === 3 && (
                <div className="space-y-6">
                  <div className="text-center">
                    <Target className="w-12 h-12 text-accent mx-auto mb-4" />
                    <CardTitle className="text-2xl mb-2">Experience & Goals</CardTitle>
                    <CardDescription>Tell us about your background and what you hope to achieve</CardDescription>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="experience">Your Experience Level</Label>
                      <Select
                        value={ideaData.experience}
                        onValueChange={(value) => setIdeaData({ ...ideaData, experience: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select your experience level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="first-time">First-time entrepreneur</SelectItem>
                          <SelectItem value="some-experience">Some business experience</SelectItem>
                          <SelectItem value="experienced">Experienced entrepreneur</SelectItem>
                          <SelectItem value="industry-expert">Industry expert</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="additionalNotes">Additional Notes</Label>
                      <Textarea
                        id="additionalNotes"
                        placeholder="Any additional information, specific challenges, resources you have, partnerships, etc."
                        value={ideaData.additionalNotes}
                        onChange={(e) => setIdeaData({ ...ideaData, additionalNotes: e.target.value })}
                        className="min-h-[120px]"
                      />
                    </div>

                    {/* Summary Preview */}
                    <div className="bg-muted/50 rounded-lg p-4">
                      <h4 className="font-semibold mb-3">Idea Summary</h4>
                      <div className="space-y-2 text-sm">
                        <div>
                          <strong>Title:</strong> {ideaData.title || "Not specified"}
                        </div>
                        <div>
                          <strong>Category:</strong> {ideaData.category || "Not specified"}
                        </div>
                        <div>
                          <strong>Location:</strong> {ideaData.location || "Not specified"}
                        </div>
                        <div>
                          <strong>Budget:</strong> {ideaData.budget || "Not specified"}
                        </div>
                        <div>
                          <strong>Timeline:</strong> {ideaData.timeline || "Not specified"}
                        </div>
                        {selectedModelInfo && (
                          <div>
                            <strong>Business Model:</strong> {selectedModelInfo.data.name}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Navigation */}
              <div className="flex justify-between mt-8">
                <Button variant="outline" onClick={handleBack} disabled={currentStep === 1}>
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
                <Button onClick={handleNext}>
                  {currentStep === 3 ? "Create Idea" : "Next"}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
