"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Slider } from "@/components/ui/slider"
import { PremiumGate } from "@/components/premium-gate"
import {
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"
import {
  ArrowLeft,
  TrendingUp,
  DollarSign,
  Users,
  Calendar,
  Target,
  BarChart3,
  PieChartIcon,
  Zap,
  Lock,
  Crown,
  MessageSquare,
  Download,
  Share,
} from "lucide-react"

// Mock data for charts
const revenueData = [
  { month: "Jan", revenue: 0, costs: 2000, profit: -2000 },
  { month: "Feb", revenue: 1200, costs: 2500, profit: -1300 },
  { month: "Mar", revenue: 3500, costs: 3000, profit: 500 },
  { month: "Apr", revenue: 5800, costs: 3200, profit: 2600 },
  { month: "May", revenue: 8200, costs: 3500, profit: 4700 },
  { month: "Jun", revenue: 12000, costs: 4000, profit: 8000 },
  { month: "Jul", revenue: 15500, costs: 4500, profit: 11000 },
  { month: "Aug", revenue: 19200, costs: 5000, profit: 14200 },
  { month: "Sep", revenue: 23800, costs: 5500, profit: 18300 },
  { month: "Oct", revenue: 28500, costs: 6000, profit: 22500 },
  { month: "Nov", revenue: 34200, costs: 6500, profit: 27700 },
  { month: "Dec", revenue: 41000, costs: 7000, profit: 34000 },
]

const costBreakdownData = [
  { name: "Marketing", value: 35, amount: 2450 },
  { name: "Operations", value: 25, amount: 1750 },
  { name: "Staff", value: 20, amount: 1400 },
  { name: "Technology", value: 12, amount: 840 },
  { name: "Legal & Admin", value: 8, amount: 560 },
]

const marketAnalysisData = [
  { segment: "Young Adults", potential: 45000, captured: 2300 },
  { segment: "Professionals", potential: 32000, captured: 1800 },
  { segment: "Students", potential: 28000, captured: 1200 },
  { segment: "Families", potential: 25000, captured: 900 },
]

const competitorData = [
  { name: "Your Business", market_share: 2.1, growth: 85, satisfaction: 4.2 },
  { name: "Competitor A", market_share: 15.3, growth: 12, satisfaction: 3.8 },
  { name: "Competitor B", market_share: 22.7, growth: 8, satisfaction: 3.5 },
  { name: "Competitor C", market_share: 18.9, growth: -2, satisfaction: 3.2 },
]

const COLORS = ["#8b5cf6", "#06b6d4", "#10b981", "#f59e0b", "#ef4444"]

export default function IdeaDetailPage() {
  const [userData, setUserData] = useState<any>(null)
  const [idea, setIdea] = useState<any>(null)
  const [timeframe, setTimeframe] = useState([12])
  const [investmentLevel, setInvestmentLevel] = useState([50])
  const [activeModel, setActiveModel] = useState("model1")
  const [simulationParams, setSimulationParams] = useState({
    marketSize: [100],
    competitionLevel: [50],
    marketingBudget: [30],
  })
  const router = useRouter()
  const params = useParams()

  useEffect(() => {
    // Check authentication
    const user = localStorage.getItem("bizpilot_user")
    if (!user) {
      router.push("/auth/login")
      return
    }
    setUserData(JSON.parse(user))

    // Load specific idea
    const ideas = JSON.parse(localStorage.getItem("bizpilot_ideas") || "[]")
    const foundIdea = ideas.find((i: any) => i.id === params.id)
    if (foundIdea) {
      setIdea(foundIdea)
    } else {
      router.push("/dashboard")
    }
  }, [router, params.id])

  if (!userData || !idea) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">Loading...</div>
      </div>
    )
  }

  const businessModelVariations = {
    model1: {
      name: "Conservative Model",
      description: "Low-risk approach with steady growth",
      revenue: revenueData,
      breakEven: "Month 3",
      roi: "340%",
      riskLevel: "Low",
    },
    model2: {
      name: "Aggressive Model",
      description: "High-growth strategy with increased investment",
      revenue: revenueData.map((item) => ({
        ...item,
        revenue: item.revenue * 1.8,
        costs: item.costs * 1.4,
        profit: item.revenue * 1.8 - item.costs * 1.4,
      })),
      breakEven: "Month 2",
      roi: "520%",
      riskLevel: "High",
    },
    model3: {
      name: "Balanced Model",
      description: "Moderate risk with balanced growth trajectory",
      revenue: revenueData.map((item) => ({
        ...item,
        revenue: item.revenue * 1.3,
        costs: item.costs * 1.15,
        profit: item.revenue * 1.3 - item.costs * 1.15,
      })),
      breakEven: "Month 3",
      roi: "425%",
      riskLevel: "Medium",
    },
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="sm" onClick={() => router.push("/dashboard")}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-accent-foreground" />
              </div>
              <span className="text-xl font-bold">BizPilot</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Badge variant="secondary">Free Plan</Badge>
            <Button variant="outline" size="sm">
              <Crown className="w-4 h-4 mr-2" />
              Upgrade to Pro
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Idea Header */}
        <div className="mb-8">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold mb-2">{idea.title}</h1>
              <p className="text-muted-foreground mb-4">{idea.description}</p>
              <div className="flex items-center space-x-4">
                <Badge variant="secondary">{idea.category}</Badge>
                <div className="flex items-center text-sm text-muted-foreground">
                  <DollarSign className="w-4 h-4 mr-1" />
                  {idea.budget}
                </div>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Calendar className="w-4 h-4 mr-1" />
                  {idea.timeline}
                </div>
              </div>
            </div>
            <Badge variant={idea.status === "draft" ? "secondary" : "default"}>{idea.status}</Badge>
          </div>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="w-5 h-5 mr-2" />
              Business Model Comparison
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Compare 3 AI-generated models side-by-side with interactive trade-offs
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              {Object.entries(businessModelVariations).map(([key, model]) => (
                <Card
                  key={key}
                  className={`cursor-pointer transition-all ${activeModel === key ? "ring-2 ring-accent" : ""}`}
                  onClick={() => setActiveModel(key)}
                >
                  <CardContent className="p-4">
                    <h3 className="font-semibold mb-2">{model.name}</h3>
                    <p className="text-xs text-muted-foreground mb-3">{model.description}</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Break-even:</span>
                        <span className="font-medium">{model.breakEven}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">ROI:</span>
                        <span className="font-medium">{model.roi}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Risk:</span>
                        <Badge
                          variant={
                            model.riskLevel === "Low"
                              ? "secondary"
                              : model.riskLevel === "Medium"
                                ? "default"
                                : "destructive"
                          }
                        >
                          {model.riskLevel}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Target className="w-5 h-5 mr-2" />
              Interactive Cost-Revenue Simulator
            </CardTitle>
            <p className="text-sm text-muted-foreground">Adjust parameters to see real-time impact on profitability</p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div>
                <label className="text-sm font-medium mb-2 block">Market Size Penetration (%)</label>
                <Slider
                  value={simulationParams.marketSize}
                  onValueChange={(value) => setSimulationParams((prev) => ({ ...prev, marketSize: value }))}
                  max={100}
                  min={1}
                  step={1}
                  className="mb-2"
                />
                <div className="text-sm text-muted-foreground">
                  {simulationParams.marketSize[0]}% market penetration
                </div>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Competition Level</label>
                <Slider
                  value={simulationParams.competitionLevel}
                  onValueChange={(value) => setSimulationParams((prev) => ({ ...prev, competitionLevel: value }))}
                  max={100}
                  min={10}
                  step={5}
                  className="mb-2"
                />
                <div className="text-sm text-muted-foreground">
                  {simulationParams.competitionLevel[0] < 30
                    ? "Low"
                    : simulationParams.competitionLevel[0] < 70
                      ? "Medium"
                      : "High"}{" "}
                  competition
                </div>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Marketing Budget (%)</label>
                <Slider
                  value={simulationParams.marketingBudget}
                  onValueChange={(value) => setSimulationParams((prev) => ({ ...prev, marketingBudget: value }))}
                  max={50}
                  min={5}
                  step={5}
                  className="mb-2"
                />
                <div className="text-sm text-muted-foreground">{simulationParams.marketingBudget[0]}% of revenue</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-muted/20 rounded-lg">
              <div className="text-center">
                <div className="text-lg font-bold text-green-600">
                  $
                  {Math.round(
                    41000 * (simulationParams.marketSize[0] / 100) * (1 - simulationParams.competitionLevel[0] / 200),
                  ).toLocaleString()}
                </div>
                <div className="text-xs text-muted-foreground">Projected Revenue</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-blue-600">
                  ${Math.round(7000 + (41000 * simulationParams.marketingBudget[0]) / 100).toLocaleString()}
                </div>
                <div className="text-xs text-muted-foreground">Total Costs</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-purple-600">
                  {Math.round(
                    ((41000 *
                      (simulationParams.marketSize[0] / 100) *
                      (1 - simulationParams.competitionLevel[0] / 200) -
                      (7000 + (41000 * simulationParams.marketingBudget[0]) / 100)) /
                      (7000 + (41000 * simulationParams.marketingBudget[0]) / 100)) *
                      100,
                  )}
                  %
                </div>
                <div className="text-xs text-muted-foreground">ROI</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AI Chat Assistant */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center">
                <MessageSquare className="w-5 h-5 mr-2" />
                AI Business Coach
              </div>
              <Badge variant="secondary" className="bg-accent/20 text-accent-foreground">
                <Crown className="w-3 h-3 mr-1" />
                Pro Feature
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <PremiumGate
              feature="AI Business Coach"
              description="Get personalized advice, market insights, and strategic recommendations from our advanced AI coach."
            >
              <div className="bg-muted/30 rounded-lg p-4 h-32">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                    <MessageSquare className="w-4 h-4 text-accent-foreground" />
                  </div>
                  <div className="bg-background rounded-lg p-3 max-w-xs">
                    <p className="text-sm">I can help you optimize your business strategy...</p>
                  </div>
                </div>
              </div>
            </PremiumGate>
          </CardContent>
        </Card>

        <Tabs defaultValue="models" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="models">Models</TabsTrigger>
            <TabsTrigger value="comparison">Compare</TabsTrigger>
            <TabsTrigger value="simulations">Simulate</TabsTrigger>
            <TabsTrigger value="financials">Financials</TabsTrigger>
            <TabsTrigger value="market">Market</TabsTrigger>
            <TabsTrigger value="advanced">
              <Lock className="w-3 h-3 mr-1" />
              Advanced
            </TabsTrigger>
          </TabsList>

          <TabsContent value="models" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>
                    Active Model: {businessModelVariations[activeModel as keyof typeof businessModelVariations].name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart
                      data={businessModelVariations[activeModel as keyof typeof businessModelVariations].revenue}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`$${value}`, ""]} />
                      <Legend />
                      <Area
                        type="monotone"
                        dataKey="revenue"
                        stackId="1"
                        stroke="#8b5cf6"
                        fill="#8b5cf6"
                        fillOpacity={0.6}
                        name="Revenue"
                      />
                      <Area
                        type="monotone"
                        dataKey="costs"
                        stackId="2"
                        stroke="#ef4444"
                        fill="#ef4444"
                        fillOpacity={0.6}
                        name="Costs"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Model Performance Metrics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {Object.entries(businessModelVariations).map(([key, model]) => (
                    <div
                      key={key}
                      className={`p-3 rounded-lg border ${activeModel === key ? "bg-accent/10 border-accent" : ""}`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">{model.name}</h4>
                        <Badge
                          variant={
                            model.riskLevel === "Low"
                              ? "secondary"
                              : model.riskLevel === "Medium"
                                ? "default"
                                : "destructive"
                          }
                        >
                          {model.riskLevel}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>Break-even: {model.breakEven}</div>
                        <div>ROI: {model.roi}</div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="comparison" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Side-by-Side Model Comparison</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-2">Metric</th>
                        {Object.entries(businessModelVariations).map(([key, model]) => (
                          <th key={key} className="text-center p-2">
                            {model.name}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b">
                        <td className="p-2 font-medium">Break-even Point</td>
                        {Object.entries(businessModelVariations).map(([key, model]) => (
                          <td key={key} className="text-center p-2">
                            {model.breakEven}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="p-2 font-medium">ROI</td>
                        {Object.entries(businessModelVariations).map(([key, model]) => (
                          <td key={key} className="text-center p-2">
                            {model.roi}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="p-2 font-medium">Risk Level</td>
                        {Object.entries(businessModelVariations).map(([key, model]) => (
                          <td key={key} className="text-center p-2">
                            <Badge
                              variant={
                                model.riskLevel === "Low"
                                  ? "secondary"
                                  : model.riskLevel === "Medium"
                                    ? "default"
                                    : "destructive"
                              }
                            >
                              {model.riskLevel}
                            </Badge>
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td className="p-2 font-medium">Year 1 Revenue</td>
                        {Object.entries(businessModelVariations).map(([key, model]) => (
                          <td key={key} className="text-center p-2">
                            ${model.revenue[11]?.revenue?.toLocaleString() || "N/A"}
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="simulations" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Interactive Business Simulations</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Adjust variables with sliders to see real-time impact on your business model
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-6">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Forecast Timeframe (months)</label>
                      <Slider
                        value={timeframe}
                        onValueChange={setTimeframe}
                        max={36}
                        min={6}
                        step={3}
                        className="mb-2"
                      />
                      <div className="text-sm text-muted-foreground">{timeframe[0]} months</div>
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">Investment Level (%)</label>
                      <Slider
                        value={investmentLevel}
                        onValueChange={setInvestmentLevel}
                        max={100}
                        min={10}
                        step={10}
                        className="mb-2"
                      />
                      <div className="text-sm text-muted-foreground">{investmentLevel[0]}% of budget</div>
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">Market Conditions</label>
                      <Slider
                        value={simulationParams.competitionLevel}
                        onValueChange={(value) => setSimulationParams((prev) => ({ ...prev, competitionLevel: value }))}
                        max={100}
                        min={10}
                        step={5}
                        className="mb-2"
                      />
                      <div className="text-sm text-muted-foreground">
                        {simulationParams.competitionLevel[0] < 30
                          ? "Favorable"
                          : simulationParams.competitionLevel[0] < 70
                            ? "Neutral"
                            : "Challenging"}{" "}
                        market conditions
                      </div>
                    </div>
                  </div>

                  <div className="bg-muted/20 rounded-lg p-4">
                    <h4 className="font-medium mb-4">Simulation Results</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span>Projected Revenue:</span>
                        <span className="font-bold text-green-600">
                          ${Math.round(41000 * (timeframe[0] / 12) * (investmentLevel[0] / 50)).toLocaleString()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Break-even Time:</span>
                        <span className="font-bold">
                          {Math.max(1, Math.round((3 * (100 - investmentLevel[0])) / 50))} months
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Risk Score:</span>
                        <span className="font-bold">
                          {Math.round((simulationParams.competitionLevel[0] + (100 - investmentLevel[0])) / 2)}/100
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Success Probability:</span>
                        <span className="font-bold text-blue-600">
                          {Math.max(
                            45,
                            Math.min(95, 85 - simulationParams.competitionLevel[0] / 5 + investmentLevel[0] / 10),
                          )}
                          %
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Existing tabs with minor enhancements */}
          <TabsContent value="financials" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Cost Breakdown */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <PieChartIcon className="w-5 h-5 mr-2" />
                    Cost Breakdown
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={costBreakdownData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, value }) => `${name}: ${value}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {costBreakdownData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value}%`, ""]} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="mt-4 space-y-2">
                    {costBreakdownData.map((item, index) => (
                      <div key={item.name} className="flex items-center justify-between text-sm">
                        <div className="flex items-center">
                          <div
                            className="w-3 h-3 rounded-full mr-2"
                            style={{ backgroundColor: COLORS[index % COLORS.length] }}
                          />
                          {item.name}
                        </div>
                        <span className="font-medium">${item.amount}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Monthly Cash Flow */}
              <Card>
                <CardHeader>
                  <CardTitle>Monthly Cash Flow</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={revenueData.slice(0, 6)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`$${value}`, ""]} />
                      <Legend />
                      <Bar dataKey="revenue" fill="#8b5cf6" name="Revenue" />
                      <Bar dataKey="costs" fill="#ef4444" name="Costs" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Financial Metrics */}
            <Card>
              <CardHeader>
                <CardTitle>Key Financial Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">$34,000</div>
                    <div className="text-sm text-muted-foreground">Net Profit (Year 1)</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">340%</div>
                    <div className="text-sm text-muted-foreground">ROI</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">$3,420</div>
                    <div className="text-sm text-muted-foreground">Monthly Recurring Revenue</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Market Analysis Tab */}
          <TabsContent value="market" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Market Segments</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={marketAnalysisData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="segment" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="potential" fill="#8b5cf6" name="Market Potential" />
                    <Bar dataKey="captured" fill="#10b981" name="Captured Market" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Market Opportunity</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Total Addressable Market</span>
                    <span className="font-bold">$2.3M</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Serviceable Market</span>
                    <span className="font-bold">$850K</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Target Market</span>
                    <span className="font-bold">$320K</span>
                  </div>
                  <Progress value={15} className="mt-4" />
                  <p className="text-sm text-muted-foreground">15% market penetration target</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Growth Projections</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Year 1 Revenue</span>
                    <span className="font-bold text-green-600">$41K</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Year 2 Revenue</span>
                    <span className="font-bold text-green-600">$125K</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Year 3 Revenue</span>
                    <span className="font-bold text-green-600">$280K</span>
                  </div>
                  <div className="mt-4 p-3 bg-accent/10 rounded-lg">
                    <p className="text-sm font-medium">Market Entry Strategy</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Focus on young adults segment first, then expand to professionals
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Competition Tab */}
          <TabsContent value="competition" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Competitive Landscape</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {competitorData.map((competitor, index) => (
                    <div key={competitor.name} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-semibold">{competitor.name}</h4>
                        {competitor.name === "Your Business" && <Badge variant="secondary">You</Badge>}
                      </div>
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Market Share</p>
                          <p className="font-bold">{competitor.market_share}%</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Growth Rate</p>
                          <p className={`font-bold ${competitor.growth > 0 ? "text-green-600" : "text-red-600"}`}>
                            {competitor.growth > 0 ? "+" : ""}
                            {competitor.growth}%
                          </p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Customer Satisfaction</p>
                          <p className="font-bold">{competitor.satisfaction}/5.0</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Premium Feature Teaser */}
            <Card className="border-accent/50 bg-accent/5">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold mb-2 flex items-center">
                      <Lock className="w-4 h-4 mr-2" />
                      Advanced Competitive Analysis
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Get detailed SWOT analysis, pricing strategies, and market positioning insights
                    </p>
                    <Button variant="outline" className="bg-transparent">
                      <Crown className="w-4 h-4 mr-2" />
                      Upgrade to Pro
                    </Button>
                  </div>
                  <div className="text-6xl opacity-20">
                    <BarChart3 />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Advanced Tab - Premium Features */}
          <TabsContent value="advanced" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <PremiumGate
                feature="Monte Carlo Simulation"
                description="Run thousands of scenarios to understand risk and probability distributions for your business outcomes."
              >
                <div className="h-48 bg-muted/20 rounded-lg flex items-center justify-center">
                  <BarChart3 className="w-16 h-16 text-muted-foreground" />
                </div>
              </PremiumGate>

              <PremiumGate
                feature="Sensitivity Analysis"
                description="Understand how changes in key variables affect your business performance and identify critical success factors."
              >
                <div className="h-48 bg-muted/20 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-16 h-16 text-muted-foreground" />
                </div>
              </PremiumGate>

              <PremiumGate
                feature="Export & Sharing"
                description="Export professional reports and share with investors, partners, or team members."
              >
                <div className="space-y-2">
                  <Button variant="outline" className="w-full bg-transparent" disabled>
                    <Download className="w-4 h-4 mr-2" />
                    Export PDF Report
                  </Button>
                  <Button variant="outline" className="w-full bg-transparent" disabled>
                    <Share className="w-4 h-4 mr-2" />
                    Share with Team
                  </Button>
                </div>
              </PremiumGate>

              <PremiumGate
                feature="Real-time Market Data"
                description="Access live market trends, competitor updates, and industry insights to stay ahead."
              >
                <div className="h-48 bg-muted/20 rounded-lg flex items-center justify-center">
                  <Users className="w-16 h-16 text-muted-foreground" />
                </div>
              </PremiumGate>
            </div>
          </TabsContent>
        </Tabs>

        {/* Premium Upgrade CTA */}
        <Card className="mt-8 bg-gradient-to-r from-accent/10 to-accent/5 border-accent/20">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold mb-2 flex items-center">
                  <Crown className="w-5 h-5 mr-2 text-accent" />
                  Unlock Full Business Intelligence
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Get unlimited AI coaching, advanced simulations, and professional export capabilities
                </p>
                <div className="flex space-x-3">
                  <Button onClick={() => router.push("/premium")}>
                    <Crown className="w-4 h-4 mr-2" />
                    Upgrade to Pro
                  </Button>
                  <Button variant="outline" className="bg-transparent">
                    Start Free Trial
                  </Button>
                </div>
              </div>
              <div className="text-6xl opacity-20">
                <Crown />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
