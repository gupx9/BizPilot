"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  BarChart3,
  Zap,
  LogOut,
  TrendingUp,
  Users,
  Package,
  Factory,
  Cloud,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  Activity,
  Lightbulb,
} from "lucide-react"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
} from "recharts"
import { AdvancedAnalytics } from "@/components/forecasting/advanced-analytics"
import { ForecastAlerts } from "@/components/forecasting/forecast-alerts"
import { ExportTools } from "@/components/forecasting/export-tools"

interface ForecastData {
  demand: number[]
  production: number[]
  inventory: number[]
  staffing: number[]
  confidence: number
  factors: string[]
  recommendations: string[]
}

interface ForecastResult {
  success: boolean
  data: {
    forecast: ForecastData
    insights: string[]
    metadata: {
      location: string
      countryCode: string
      businessType: string
      timeHorizon: number
      generatedAt: string
    }
  }
}

export default function OperationsPage() {
  const [userData, setUserData] = useState<any>(null)
  const [scrapedData, setScrapedData] = useState<any[]>([])
  const [analysisResults, setAnalysisResults] = useState<any>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [forecastResult, setForecastResult] = useState<ForecastResult | null>(null)
  const [isForecasting, setIsForecasting] = useState(false)
  const [isScraping, setIsScraping] = useState(false)
  const [isCreatingIdeaAndForecast, setIsCreatingIdeaAndForecast] = useState(false)
  const [currentIdea, setCurrentIdea] = useState<any>(null)

  const [forecastForm, setForecastForm] = useState({
    location: "",
    countryCode: "US",
    businessType: "retail",
    timeHorizon: 12,
  })

  const [scrapingConfig, setScrapingConfig] = useState({
    businessType: "retail",
    industry: "",
    location: "",
    countryCode: "US",
    dataTypes: ["sales", "market", "competitor"],
  })

  const router = useRouter()

  useEffect(() => {
    const user = localStorage.getItem("bizpilot_user")
    if (!user) {
      router.push("/auth/login")
      return
    }
    setUserData(JSON.parse(user))
  }, [router])

  const handleDataScraping = async (dataTypes: string[]) => {
    if (!scrapingConfig.location || !scrapingConfig.businessType) {
      alert("Please fill in location and business type first")
      return
    }

    setIsScraping(true)
    try {
      console.log("[v0] Starting data scraping with config:", { ...scrapingConfig, dataTypes })

      const response = await fetch("/api/scrape-data", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...scrapingConfig,
          dataTypes,
        }),
      })

      if (response.ok) {
        const result = await response.json()
        console.log("[v0] Scraping successful:", result.summary)

        setScrapedData((prev) => [...prev, ...result.data])

        // Automatically analyze the scraped data
        await analyzeScrapedData(result.data)
      } else {
        const error = await response.json()
        console.error("Scraping failed:", error)
        alert("Data scraping failed. Please try again.")
      }
    } catch (error) {
      console.error("Scraping failed:", error)
      alert("Data scraping failed. Please check your connection.")
    } finally {
      setIsScraping(false)
    }
  }

  const analyzeScrapedData = async (data: any[]) => {
    setIsAnalyzing(true)
    try {
      const response = await fetch("/api/analyze-data", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          data: data.flatMap((d) => d.data),
          dataType: "scraped",
          analysisType: "comprehensive",
        }),
      })

      if (response.ok) {
        const result = await response.json()
        setAnalysisResults(result)
      }
    } catch (error) {
      console.error("Analysis failed:", error)
    } finally {
      setIsAnalyzing(false)
    }
  }

  const generateForecast = async () => {
    if (!forecastForm.location || !forecastForm.countryCode || !forecastForm.businessType) {
      alert("Please fill in all required fields")
      return
    }

    setIsForecasting(true)
    try {
      const response = await fetch("/api/forecast", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          location: forecastForm.location,
          countryCode: forecastForm.countryCode,
          businessType: forecastForm.businessType,
          timeHorizon: forecastForm.timeHorizon,
          historicalData: scrapedData.filter((d) => d.type === "sales").flatMap((d) => d.data),
        }),
      })

      if (response.ok) {
        const result: ForecastResult = await response.json()
        setForecastResult(result)
      } else {
        const error = await response.json()
        console.error("Forecast failed:", error)
        alert("Forecast generation failed. Please try again.")
      }
    } catch (error) {
      console.error("Forecast failed:", error)
      alert("Forecast generation failed. Please check your connection.")
    } finally {
      setIsForecasting(false)
    }
  }

  const handleUnifiedIdeaToForecast = async () => {
    setIsCreatingIdeaAndForecast(true)

    try {
      // Step 1: Create a quick business idea
      console.log("[v0] Starting unified idea creation and forecast workflow")

      // For demo purposes, we'll create a simplified idea creation flow
      // In a real implementation, you might want to show a modal or redirect to idea creation
      const quickIdea = {
        id: Date.now().toString(),
        title: "AI-Generated Business Opportunity",
        description: "Business opportunity identified through market analysis and forecasting",
        category: forecastForm.businessType,
        location: forecastForm.location,
        budget: "10k-25k", // Default budget
        timeline: "6-12-months", // Default timeline
        targetMarket: "Local market analysis pending",
        experience: "some-experience",
        additionalNotes: "Generated through BizPilot's unified analysis workflow",
        createdAt: new Date().toISOString(),
        status: "draft",
        userId: userData.email,
        generatedFromForecast: true,
      }

      // Save the idea
      const existingIdeas = JSON.parse(localStorage.getItem("bizpilot_ideas") || "[]")
      existingIdeas.push(quickIdea)
      localStorage.setItem("bizpilot_ideas", JSON.stringify(existingIdeas))

      setCurrentIdea(quickIdea)
      console.log("[v0] Quick idea created:", quickIdea)

      // Step 2: Use the idea data to populate forecast parameters and run forecast
      const ideaBasedForecastParams = {
        location: quickIdea.location,
        countryCode: forecastForm.countryCode,
        businessType: quickIdea.category,
        timeHorizon:
          quickIdea.timeline === "6-12-months"
            ? 12
            : quickIdea.timeline === "3-6-months"
              ? 6
              : quickIdea.timeline === "1-3-months"
                ? 3
                : 12,
      }

      console.log("[v0] Running forecast with idea-based parameters:", ideaBasedForecastParams)

      const response = await fetch("/api/forecast", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...ideaBasedForecastParams,
          historicalData: scrapedData.filter((d) => d.type === "sales").flatMap((d) => d.data),
        }),
      })

      if (response.ok) {
        const result: ForecastResult = await response.json()
        setForecastResult(result)

        // Update the idea with forecast insights
        const updatedIdea = {
          ...quickIdea,
          forecastData: result.data,
          status: "analyzed",
        }

        // Update localStorage
        const updatedIdeas = existingIdeas.map((idea: any) => (idea.id === quickIdea.id ? updatedIdea : idea))
        localStorage.setItem("bizpilot_ideas", JSON.stringify(updatedIdeas))
        setCurrentIdea(updatedIdea)

        console.log("[v0] Unified workflow completed successfully")
      } else {
        const error = await response.json()
        console.error("Unified forecast failed:", error)
        alert("Forecast generation failed. Please try again.")
      }
    } catch (error) {
      console.error("Unified workflow failed:", error)
      alert("Unified analysis failed. Please check your connection.")
    } finally {
      setIsCreatingIdeaAndForecast(false)
    }
  }

  const getChartData = () => {
    if (!forecastResult?.data.forecast) return []

    const { forecast } = forecastResult.data
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

    return forecast.demand.map((_, index) => ({
      month: months[index % 12],
      demand: forecast.demand[index],
      production: forecast.production[index],
      inventory: forecast.inventory[index],
      staffing: forecast.staffing[index],
    }))
  }

  const handleLogout = () => {
    localStorage.removeItem("bizpilot_user")
    router.push("/")
  }

  if (!userData) {
    return <div className="min-h-screen bg-background flex items-center justify-center">Loading...</div>
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-accent-foreground" />
            </div>
            <span className="text-xl font-bold">BizPilot</span>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="sm" onClick={() => router.push("/dashboard")}>
              Dashboard
            </Button>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Predictive Operations Center</h1>
          <p className="text-muted-foreground">
            AI-driven forecasting with automated web scraping from industry data sources, economic indicators, and
            competitor analysis
          </p>
        </div>

        <Card className="mb-8 border-accent/20 bg-gradient-to-r from-accent/5 to-accent/10">
          <CardHeader>
            <CardTitle className="flex items-center text-2xl">
              <Zap className="w-6 h-6 mr-3 text-accent" />
              Unified Business Analysis
            </CardTitle>
            <p className="text-muted-foreground">
              Create a business idea and get instant AI-powered forecasting and market analysis in one click
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="unified-location">Business Location</Label>
                <Input
                  id="unified-location"
                  placeholder="e.g., New York, London, Tokyo"
                  value={forecastForm.location}
                  onChange={(e) => setForecastForm((prev) => ({ ...prev, location: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="unified-business-type">Business Type</Label>
                <Select
                  value={forecastForm.businessType}
                  onValueChange={(value) => setForecastForm((prev) => ({ ...prev, businessType: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="retail">Retail</SelectItem>
                    <SelectItem value="restaurant">Restaurant</SelectItem>
                    <SelectItem value="manufacturing">Manufacturing</SelectItem>
                    <SelectItem value="services">Services</SelectItem>
                    <SelectItem value="ecommerce">E-commerce</SelectItem>
                    <SelectItem value="healthcare">Healthcare</SelectItem>
                    <SelectItem value="technology">Technology</SelectItem>
                    <SelectItem value="construction">Construction</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {currentIdea && (
              <div className="bg-accent/10 border border-accent/20 rounded-lg p-4">
                <h4 className="font-semibold text-accent mb-2">Current Business Idea</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Title:</span> {currentIdea.title}
                  </div>
                  <div>
                    <span className="font-medium">Category:</span> {currentIdea.category}
                  </div>
                  <div>
                    <span className="font-medium">Location:</span> {currentIdea.location}
                  </div>
                  <div>
                    <span className="font-medium">Status:</span>
                    <Badge variant={currentIdea.status === "analyzed" ? "default" : "secondary"} className="ml-2">
                      {currentIdea.status}
                    </Badge>
                  </div>
                </div>
              </div>
            )}

            <Button
              onClick={handleUnifiedIdeaToForecast}
              disabled={isCreatingIdeaAndForecast || !forecastForm.location || !forecastForm.businessType}
              className="w-full"
              size="lg"
            >
              {isCreatingIdeaAndForecast ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Creating Idea & Generating Forecast...
                </>
              ) : (
                <>
                  <Lightbulb className="w-4 h-4 mr-2" />
                  Create Business Idea & Generate Forecast
                </>
              )}
            </Button>

            <p className="text-xs text-muted-foreground text-center">
              This will create a business idea based on your inputs and immediately run AI forecasting analysis
            </p>
          </CardContent>
        </Card>

        <Tabs defaultValue="data-collection" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="data-collection">Data Scraping</TabsTrigger>
            <TabsTrigger value="forecasting">AI Forecasting</TabsTrigger>
            <TabsTrigger value="analytics">Predictive Analytics</TabsTrigger>
            <TabsTrigger value="insights">Business Insights</TabsTrigger>
          </TabsList>

          <TabsContent value="data-collection" className="space-y-6">
            {/* Web Scraping Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Cloud className="w-5 h-5 mr-2" />
                  Web Scraping Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="scraping-location">Business Location</Label>
                    <Input
                      id="scraping-location"
                      placeholder="e.g., New York, London, Tokyo"
                      value={scrapingConfig.location}
                      onChange={(e) => setScrapingConfig((prev) => ({ ...prev, location: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="scraping-business-type">Business Type</Label>
                    <Select
                      value={scrapingConfig.businessType}
                      onValueChange={(value) => setScrapingConfig((prev) => ({ ...prev, businessType: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="retail">Retail</SelectItem>
                        <SelectItem value="restaurant">Restaurant</SelectItem>
                        <SelectItem value="manufacturing">Manufacturing</SelectItem>
                        <SelectItem value="services">Services</SelectItem>
                        <SelectItem value="ecommerce">E-commerce</SelectItem>
                        <SelectItem value="healthcare">Healthcare</SelectItem>
                        <SelectItem value="technology">Technology</SelectItem>
                        <SelectItem value="construction">Construction</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="scraping-industry">Industry (Optional)</Label>
                    <Input
                      id="scraping-industry"
                      placeholder="e.g., Fashion, Food Service, Software"
                      value={scrapingConfig.industry}
                      onChange={(e) => setScrapingConfig((prev) => ({ ...prev, industry: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="scraping-country">Country</Label>
                    <Select
                      value={scrapingConfig.countryCode}
                      onValueChange={(value) => setScrapingConfig((prev) => ({ ...prev, countryCode: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="US">United States</SelectItem>
                        <SelectItem value="GB">United Kingdom</SelectItem>
                        <SelectItem value="CA">Canada</SelectItem>
                        <SelectItem value="AU">Australia</SelectItem>
                        <SelectItem value="DE">Germany</SelectItem>
                        <SelectItem value="FR">France</SelectItem>
                        <SelectItem value="JP">Japan</SelectItem>
                        <SelectItem value="CN">China</SelectItem>
                        <SelectItem value="IN">India</SelectItem>
                        <SelectItem value="BR">Brazil</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Data Scraping Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <DollarSign className="w-5 h-5 mr-2 flex-shrink-0" />
                    <span className="truncate">Sales & Market Data</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Scrape industry sales data, market trends, and economic indicators
                  </p>
                  <Button
                    variant="outline"
                    className="w-full bg-transparent"
                    onClick={() => handleDataScraping(["sales", "market"])}
                    disabled={isScraping || !scrapingConfig.location}
                  >
                    <Cloud className="w-4 h-4 mr-2 flex-shrink-0" />
                    <span className="truncate">Scrape Sales Data</span>
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Package className="w-5 h-5 mr-2 flex-shrink-0" />
                    <span className="truncate">Inventory & Production</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Gather industry inventory levels and production capacity data
                  </p>
                  <Button
                    variant="outline"
                    className="w-full bg-transparent"
                    onClick={() => handleDataScraping(["inventory", "production"])}
                    disabled={isScraping || !scrapingConfig.location}
                  >
                    <Cloud className="w-4 h-4 mr-2 flex-shrink-0" />
                    <span className="truncate">Scrape Inventory Data</span>
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="w-5 h-5 mr-2 flex-shrink-0" />
                    <span className="truncate">Staffing & Competitor</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Analyze staffing trends and competitor performance data
                  </p>
                  <Button
                    variant="outline"
                    className="w-full bg-transparent"
                    onClick={() => handleDataScraping(["staffing", "competitor"])}
                    disabled={isScraping || !scrapingConfig.location}
                  >
                    <Cloud className="w-4 h-4 mr-2 flex-shrink-0" />
                    <span className="truncate">Scrape Staffing Data</span>
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Scraped Data Display */}
            {scrapedData.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Scraped Data Sources</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {scrapedData.map((data, index) => (
                      <div key={index} className="flex items-center justify-between p-4 border rounded-lg min-w-0">
                        <div className="flex items-center space-x-3 min-w-0 flex-1">
                          <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                            {data.type === "sales" && <DollarSign className="w-5 h-5 text-accent" />}
                            {data.type === "inventory" && <Package className="w-5 h-5 text-accent" />}
                            {data.type === "staffing" && <Users className="w-5 h-5 text-accent" />}
                            {data.type === "market" && <BarChart3 className="w-5 h-5 text-accent" />}
                            {data.type === "competitor" && <TrendingUp className="w-5 h-5 text-accent" />}
                          </div>
                          <div className="min-w-0 flex-1">
                            <h4 className="font-medium truncate">{data.source}</h4>
                            <p className="text-sm text-muted-foreground truncate">
                              {data.type} • {data.data.length} records • Confidence: {Math.round(data.confidence * 100)}
                              %
                            </p>
                          </div>
                        </div>
                        <Badge variant="secondary" className="flex items-center flex-shrink-0">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Scraped
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Comprehensive Scraping Button */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="w-5 h-5 mr-2" />
                  Comprehensive Data Collection
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Scrape all available data sources for your business type and location
                </p>
                <Button
                  onClick={() => handleDataScraping(["sales", "inventory", "staffing", "market", "competitor"])}
                  disabled={isScraping || !scrapingConfig.location || !scrapingConfig.businessType}
                  className="w-full"
                  size="lg"
                >
                  {isScraping ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                      Scraping Data Sources...
                    </>
                  ) : (
                    <>
                      <Cloud className="w-4 h-4 mr-2" />
                      Scrape All Data Sources
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="forecasting" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="w-5 h-5 mr-2" />
                  AI Forecasting Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="location">Business Location</Label>
                    <Input
                      id="location"
                      placeholder="e.g., New York, London, Tokyo"
                      value={forecastForm.location}
                      onChange={(e) => setForecastForm((prev) => ({ ...prev, location: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="country">Country Code</Label>
                    <Select
                      value={forecastForm.countryCode}
                      onValueChange={(value) => setForecastForm((prev) => ({ ...prev, countryCode: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="US">United States</SelectItem>
                        <SelectItem value="GB">United Kingdom</SelectItem>
                        <SelectItem value="CA">Canada</SelectItem>
                        <SelectItem value="AU">Australia</SelectItem>
                        <SelectItem value="DE">Germany</SelectItem>
                        <SelectItem value="FR">France</SelectItem>
                        <SelectItem value="JP">Japan</SelectItem>
                        <SelectItem value="CN">China</SelectItem>
                        <SelectItem value="IN">India</SelectItem>
                        <SelectItem value="BR">Brazil</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="business-type">Business Type</Label>
                    <Select
                      value={forecastForm.businessType}
                      onValueChange={(value) => setForecastForm((prev) => ({ ...prev, businessType: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="retail">Retail</SelectItem>
                        <SelectItem value="restaurant">Restaurant</SelectItem>
                        <SelectItem value="manufacturing">Manufacturing</SelectItem>
                        <SelectItem value="services">Services</SelectItem>
                        <SelectItem value="ecommerce">E-commerce</SelectItem>
                        <SelectItem value="healthcare">Healthcare</SelectItem>
                        <SelectItem value="technology">Technology</SelectItem>
                        <SelectItem value="construction">Construction</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="time-horizon">Forecast Period (Months)</Label>
                    <Select
                      value={forecastForm.timeHorizon.toString()}
                      onValueChange={(value) =>
                        setForecastForm((prev) => ({ ...prev, timeHorizon: Number.parseInt(value) }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="3">3 Months</SelectItem>
                        <SelectItem value="6">6 Months</SelectItem>
                        <SelectItem value="12">12 Months</SelectItem>
                        <SelectItem value="18">18 Months</SelectItem>
                        <SelectItem value="24">24 Months</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="pt-4">
                  <Button
                    onClick={generateForecast}
                    disabled={isForecasting || !forecastForm.location}
                    className="w-full"
                    size="lg"
                  >
                    {isForecasting ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                        Generating AI Forecast...
                      </>
                    ) : (
                      <>
                        <TrendingUp className="w-4 h-4 mr-2" />
                        Generate Predictive Forecast
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* External Data Sources Status */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3 min-w-0">
                    <Cloud className="w-8 h-8 text-blue-500 flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <h3 className="font-medium truncate">Weather Data</h3>
                      <p className="text-sm text-muted-foreground truncate">OpenWeatherMap API</p>
                    </div>
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3 min-w-0">
                    <DollarSign className="w-8 h-8 text-yellow-500 flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <h3 className="font-medium truncate">Financial Data</h3>
                      <p className="text-sm text-muted-foreground truncate">Alpha Vantage API</p>
                    </div>
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3 min-w-0">
                    <BarChart3 className="w-8 h-8 text-green-500 flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <h3 className="font-medium truncate">Economic Data</h3>
                      <p className="text-sm text-muted-foreground truncate">World Bank API</p>
                    </div>
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3 min-w-0">
                    <Zap className="w-8 h-8 text-purple-500 flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <h3 className="font-medium truncate">AI Processing</h3>
                      <p className="text-sm text-muted-foreground truncate">Groq Llama 3.1</p>
                    </div>
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            {forecastResult ? (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-2 min-w-0">
                        <TrendingUp className="w-5 h-5 text-blue-500 flex-shrink-0" />
                        <div className="min-w-0 flex-1">
                          <p className="text-sm text-muted-foreground truncate">Forecast Confidence</p>
                          <p className="text-2xl font-bold">
                            {Math.round(forecastResult.data.forecast.confidence * 100)}%
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-2 min-w-0">
                        <DollarSign className="w-5 h-5 text-green-500 flex-shrink-0" />
                        <div className="min-w-0 flex-1">
                          <p className="text-sm text-muted-foreground truncate">Avg Demand</p>
                          <p className="text-2xl font-bold">
                            {Math.round(
                              forecastResult.data.forecast.demand.reduce((a, b) => a + b, 0) /
                                forecastResult.data.forecast.demand.length,
                            )}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-2 min-w-0">
                        <Factory className="w-5 h-5 text-orange-500 flex-shrink-0" />
                        <div className="min-w-0 flex-1">
                          <p className="text-sm text-muted-foreground truncate">Avg Production</p>
                          <p className="text-2xl font-bold">
                            {Math.round(
                              forecastResult.data.forecast.production.reduce((a, b) => a + b, 0) /
                                forecastResult.data.forecast.production.length,
                            )}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-2 min-w-0">
                        <Users className="w-5 h-5 text-purple-500 flex-shrink-0" />
                        <div className="min-w-0 flex-1">
                          <p className="text-sm text-muted-foreground truncate">Avg Staffing</p>
                          <p className="text-2xl font-bold">
                            {Math.round(
                              forecastResult.data.forecast.staffing.reduce((a, b) => a + b, 0) /
                                forecastResult.data.forecast.staffing.length,
                            )}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>Operational Forecasting Dashboard</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="w-full h-96 min-w-0">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={getChartData()}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Line type="monotone" dataKey="demand" stroke="#3b82f6" strokeWidth={2} name="Demand" />
                          <Line
                            type="monotone"
                            dataKey="production"
                            stroke="#f59e0b"
                            strokeWidth={2}
                            name="Production"
                          />
                          <Line type="monotone" dataKey="inventory" stroke="#10b981" strokeWidth={2} name="Inventory" />
                          <Line type="monotone" dataKey="staffing" stroke="#8b5cf6" strokeWidth={2} name="Staffing" />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Demand Trend Analysis</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="w-full h-64 min-w-0">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={getChartData()}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis />
                          <Tooltip />
                          <Area type="monotone" dataKey="demand" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.3} />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                <AdvancedAnalytics
                  forecastData={forecastResult.data.forecast}
                  metadata={forecastResult.data.metadata}
                />

                <ForecastAlerts forecastData={forecastResult.data.forecast} />

                <ExportTools forecastData={forecastResult.data.forecast} metadata={forecastResult.data.metadata} />
              </>
            ) : (
              <Card>
                <CardContent className="p-8 text-center">
                  <TrendingUp className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">No Forecast Data Available</h3>
                  <p className="text-muted-foreground mb-4">
                    Generate a forecast to view predictive analytics and visualizations
                  </p>
                  <Button onClick={() => document.querySelector('[value="forecasting"]')?.click()}>
                    Go to Forecasting
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="insights" className="space-y-6">
            {forecastResult ? (
              <>
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <AlertTriangle className="w-5 h-5 mr-2" />
                      Key Influencing Factors
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {forecastResult.data.forecast.factors.map((factor, index) => (
                        <div key={index} className="flex items-center space-x-2 p-3 bg-muted rounded-lg min-w-0">
                          <Badge variant="outline" className="truncate">
                            {factor}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <CheckCircle className="w-5 h-5 mr-2" />
                      AI-Generated Business Insights
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {forecastResult.data.insights.map((insight, index) => (
                        <div key={index} className="p-4 border-l-4 border-accent bg-accent/5 rounded-r-lg">
                          <p className="text-sm">{insight}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <TrendingUp className="w-5 h-5 mr-2" />
                      Strategic Recommendations
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {forecastResult.data.forecast.recommendations.map((recommendation, index) => (
                        <div key={index} className="flex items-start space-x-3 p-3 bg-card border rounded-lg">
                          <div className="w-6 h-6 bg-accent rounded-full flex items-center justify-center text-xs font-bold text-accent-foreground flex-shrink-0">
                            {index + 1}
                          </div>
                          <p className="text-sm flex-1 min-w-0">{recommendation}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Forecast Metadata</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                      <div className="min-w-0">
                        <p className="text-muted-foreground">Location</p>
                        <p className="font-medium truncate">{forecastResult.data.metadata.location}</p>
                      </div>
                      <div className="min-w-0">
                        <p className="text-muted-foreground">Business Type</p>
                        <p className="font-medium capitalize truncate">{forecastResult.data.metadata.businessType}</p>
                      </div>
                      <div className="min-w-0">
                        <p className="text-muted-foreground">Time Horizon</p>
                        <p className="font-medium">{forecastResult.data.metadata.timeHorizon} months</p>
                      </div>
                      <div className="min-w-0">
                        <p className="text-muted-foreground">Generated</p>
                        <p className="font-medium">
                          {new Date(forecastResult.data.metadata.generatedAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card>
                <CardContent className="p-8 text-center">
                  <CheckCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">No Insights Available</h3>
                  <p className="text-muted-foreground mb-4">
                    Generate a forecast to view AI-powered business insights and recommendations
                  </p>
                  <Button onClick={() => document.querySelector('[value="forecasting"]')?.click()}>
                    Generate Forecast
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>

        {/* Analysis Results */}
        {analysisResults && (
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Data Analysis Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose max-w-none">
                <pre className="whitespace-pre-wrap text-sm bg-muted p-4 rounded-lg">{analysisResults.analysis}</pre>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Loading States */}
        {(isAnalyzing || isForecasting || isScraping || isCreatingIdeaAndForecast) && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <Card className="w-full max-w-md mx-4">
              <CardContent className="p-6 text-center">
                <div className="w-8 h-8 border-4 border-accent border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                <h3 className="font-semibold mb-2">
                  {isScraping
                    ? "Scraping Industry Data"
                    : isAnalyzing
                      ? "Analyzing Your Data"
                      : isCreatingIdeaAndForecast
                        ? "Creating Idea & Forecasting"
                        : "Generating AI Forecast"}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {isScraping
                    ? "Collecting data from industry sources, economic APIs, and competitor analysis..."
                    : isAnalyzing
                      ? "Our AI is processing your scraped data to generate insights..."
                      : isCreatingIdeaAndForecast
                        ? "Creating your business idea and running comprehensive market analysis..."
                        : "Integrating weather, economic data, and AI predictions..."}
                </p>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
