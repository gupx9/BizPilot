import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { groq } from "@ai-sdk/groq"

function truncateData(data: any, maxLength = 3000): string {
  const dataStr = JSON.stringify(data)
  if (dataStr.length <= maxLength) {
    return dataStr
  }

  // If data is too large, create a summary
  if (Array.isArray(data)) {
    const sample = data.slice(0, 3)
    return JSON.stringify({
      summary: `Large dataset with ${data.length} items`,
      sample: sample,
      totalItems: data.length,
    })
  } else if (typeof data === "object" && data !== null) {
    const keys = Object.keys(data)
    const truncated: any = {}
    let currentLength = 0

    for (const key of keys) {
      const valueStr = JSON.stringify(data[key])
      if (currentLength + valueStr.length < maxLength) {
        truncated[key] = data[key]
        currentLength += valueStr.length
      } else {
        truncated[key] = `[Truncated - ${valueStr.length} chars]`
      }
    }
    return JSON.stringify(truncated)
  }

  return dataStr.substring(0, maxLength) + "... [truncated]"
}

export async function POST(request: NextRequest) {
  try {
    const { data, dataType, analysisType } = await request.json()

    const truncatedData = truncateData(data, 3000)

    console.log("[v0] Analyzing data with length:", truncatedData.length)

    const { text } = await generateText({
      model: groq("llama-3.3-70b-versatile"),
      prompt: `You are BizPilot's data analysis engine. Analyze this ${dataType} data and provide insights for a Bangladesh-based business.

Data: ${truncatedData}
Analysis Type: ${analysisType}

Provide:
1. Key insights and patterns
2. Forecasting recommendations
3. Operational suggestions (inventory, staffing, production)
4. Risk alerts and opportunities
5. Specific action items with timelines
6. Bangladesh market context and local considerations

Format as actionable recommendations with specific numbers and steps.`,
      maxTokens: 1500,
    })

    return NextResponse.json({ analysis: text })
  } catch (error) {
    console.error("Error analyzing data:", error)
    return NextResponse.json({ error: "Failed to analyze data" }, { status: 500 })
  }
}
