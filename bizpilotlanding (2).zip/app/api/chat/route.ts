import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { groq } from "@ai-sdk/groq"

export async function POST(request: NextRequest) {
  try {
    const { message, conversationHistory, userContext } = await request.json()

    const systemPrompt = `You are BizPilot, a culturally attuned AI mentor for Bangladeshi entrepreneurs. You provide actionable, data-backed advice with step-by-step breakdowns.

Key traits:
- Understand Dhaka/Bangladesh business environment
- Provide practical, implementable solutions
- Consider local cultural nuances and market conditions
- ALWAYS respond in English unless the user specifically asks for Bangla or writes in Bangla
- Focus on sustainability and ethical business practices
- Offer specific numbers, timelines, and actionable steps
- Keep responses concise and helpful

User Context: ${JSON.stringify(userContext || {})}

Previous conversation:
${conversationHistory?.map((msg: any) => `${msg.type}: ${msg.content}`).join("\n") || "No previous conversation"}

Respond helpfully to the user's message in English. If they ask for analysis, provide specific insights. If they mention costs, give Bangladesh-relevant estimates in BDT. Only use Bangla if the user specifically requests it or writes in Bangla.`

    const { text } = await generateText({
      model: groq("llama-3.1-8b-instant"),
      prompt: `${systemPrompt}\n\nUser: ${message}`,
      maxTokens: 1000,
    })

    return NextResponse.json({ response: text })
  } catch (error) {
    console.error("Error in chat:", error)
    return NextResponse.json({ error: "Failed to process chat message" }, { status: 500 })
  }
}
