import { type NextRequest, NextResponse } from "next/server"
import { forecastingEngine } from "@/lib/forecasting-engine"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { location, countryCode, businessType, historicalData = [], timeHorizon = 12 } = body

    if (!location || typeof location !== "string" || location.trim() === "") {
      return NextResponse.json({ error: "Missing or invalid location parameter" }, { status: 400 })
    }

    if (!countryCode || typeof countryCode !== "string" || countryCode.trim() === "") {
      return NextResponse.json({ error: "Missing or invalid countryCode parameter" }, { status: 400 })
    }

    if (!businessType || typeof businessType !== "string" || businessType.trim() === "") {
      return NextResponse.json({ error: "Missing or invalid businessType parameter" }, { status: 400 })
    }

    console.log("[v0] Forecast request params:", { location, countryCode, businessType, timeHorizon })

    // Collect external data
    const data = await forecastingEngine.collectData(location.trim(), countryCode.trim(), businessType.trim())

    // Generate forecast
    const forecast = await forecastingEngine.generateForecast(
      {
        historical: historicalData,
        weather: data.weather,
        economic: data.economic,
        seasonal: data.seasonal,
        external: data,
      },
      historicalData,
      timeHorizon,
    )

    // Generate business insights
    const insights = await forecastingEngine.generateInsights(forecast, {
      businessType: businessType.trim(),
      location: location.trim(),
      timeHorizon,
    })

    return NextResponse.json({
      success: true,
      data: {
        forecast,
        insights,
        metadata: {
          location: location.trim(),
          countryCode: countryCode.trim(),
          businessType: businessType.trim(),
          timeHorizon,
          generatedAt: new Date().toISOString(),
        },
      },
    })
  } catch (error) {
    console.error("Error generating forecast:", error)
    console.error("Forecast API error:", error)
    return NextResponse.json(
      {
        error: "Failed to generate forecast",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
