import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { groq } from "@ai-sdk/groq"

export async function POST(request: NextRequest) {
  try {
    const { idea, industry, budget, timeline, location } = await request.json()

    console.log("[v0] Generating models for:", { idea, industry, budget, timeline, location })

    const { text } = await generateText({
      model: groq("llama-3.1-8b-instant"),
      prompt: `You are BizPilot, a culturally attuned AI mentor for Bangladeshi entrepreneurs. Generate 3 distinct business models for this idea, specifically tailored for ${location || "Dhaka, Bangladesh"} market.

Business Idea: ${idea}
Industry: ${industry}
Budget: ${budget} BDT
Timeline: ${timeline}

CRITICAL: Return ONLY a valid JSON object. Do not include any text before or after the JSON. Ensure all property names are in double quotes.

Return your response as a valid JSON object with this exact structure:
{
  "models": [
    {
      "id": "model-1",
      "name": "Conservative Model Name",
      "description": "Brief description",
      "riskLevel": "conservative",
      "marketEntry": {
        "strategy": "Market entry strategy",
        "timeline": "6-12 months",
        "keySteps": ["Step 1", "Step 2", "Step 3"]
      },
      "financials": {
        "initialInvestment": 500000,
        "monthlyOperatingCost": 50000,
        "projectedMonthlyRevenue": 80000,
        "breakEvenMonths": 8,
        "costBreakdown": {
          "materials": 30000,
          "labor": 15000,
          "marketing": 8000,
          "overhead": 5000,
          "other": 2000
        }
      },
      "operations": {
        "staffingPlan": [
          {"role": "Manager", "count": 1, "salary": 25000},
          {"role": "Staff", "count": 2, "salary": 15000}
        ],
        "suppliers": ["Local Supplier 1", "Local Supplier 2"],
        "keyProcesses": ["Process 1", "Process 2"]
      },
      "risks": ["Risk 1", "Risk 2"],
      "opportunities": ["Opportunity 1", "Opportunity 2"],
      "sustainabilityScore": 7
    }
  ]
}

Generate 3 models with risk levels: conservative, balanced, aggressive.

Consider local factors:
- Dhaka's traffic and logistics challenges
- Local consumer behavior and cultural preferences  
- Bangladesh regulatory environment
- Seasonal business patterns
- Local competition landscape
- Available local talent and skills

Make recommendations actionable and data-backed with step-by-step breakdowns. Return ONLY the JSON object, no additional text.`,
    })

    console.log("[v0] AI Response received, length:", text.length)
    console.log("[v0] First 200 chars:", text.substring(0, 200))

    let cleanedText = text.trim()

    // Remove any markdown code blocks if present
    if (cleanedText.startsWith("```json")) {
      cleanedText = cleanedText.replace(/^```json\s*/, "").replace(/\s*```$/, "")
    } else if (cleanedText.startsWith("```")) {
      cleanedText = cleanedText.replace(/^```\s*/, "").replace(/\s*```$/, "")
    }

    // Find the first { and last } to extract just the JSON
    const firstBrace = cleanedText.indexOf("{")
    const lastBrace = cleanedText.lastIndexOf("}")

    if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
      cleanedText = cleanedText.substring(firstBrace, lastBrace + 1)
    }

    console.log("[v0] Cleaned text for parsing:", cleanedText.substring(0, 200))

    try {
      const parsedResponse = JSON.parse(cleanedText)
      console.log("[v0] Successfully parsed AI response")
      return NextResponse.json(parsedResponse)
    } catch (parseError) {
      console.error("[v0] Error parsing AI response:", parseError)
      console.error("[v0] Raw AI response:", text)

      const budgetNum = Number.parseInt(budget?.toString().replace(/[^\d]/g, "")) || 100000

      return NextResponse.json({
        models: [
          {
            id: "fallback-conservative",
            name: "Conservative Market Entry",
            description: `A low-risk approach for ${idea} in ${location || "Dhaka, Bangladesh"}`,
            riskLevel: "conservative",
            marketEntry: {
              strategy: "Start small with local market testing and gradual expansion",
              timeline: "8-12 months",
              keySteps: [
                "Conduct thorough market research",
                "Develop minimum viable product",
                "Test with small customer base",
                "Refine based on feedback",
                "Scale operations gradually",
              ],
            },
            financials: {
              initialInvestment: Math.floor(budgetNum * 0.4),
              monthlyOperatingCost: Math.floor(budgetNum * 0.06),
              projectedMonthlyRevenue: Math.floor(budgetNum * 0.1),
              breakEvenMonths: 8,
              costBreakdown: {
                materials: Math.floor(budgetNum * 0.02),
                labor: Math.floor(budgetNum * 0.025),
                marketing: Math.floor(budgetNum * 0.01),
                overhead: Math.floor(budgetNum * 0.008),
                other: Math.floor(budgetNum * 0.005),
              },
            },
            operations: {
              staffingPlan: [
                { role: "Business Manager", count: 1, salary: 30000 },
                { role: "Operations Assistant", count: 1, salary: 18000 },
              ],
              suppliers: [`Local ${industry} suppliers in ${location || "Dhaka"}`],
              keyProcesses: ["Quality assurance", "Customer relationship management", "Inventory management"],
            },
            risks: ["Market acceptance uncertainty", "Competition from established players", "Economic fluctuations"],
            opportunities: [
              "Growing digital adoption",
              "Untapped local market segments",
              "Government support for SMEs",
            ],
            sustainabilityScore: 8,
          },
          {
            id: "fallback-balanced",
            name: "Balanced Growth Strategy",
            description: `A moderate-risk balanced approach for ${idea}`,
            riskLevel: "balanced",
            marketEntry: {
              strategy: "Strategic market entry with measured expansion",
              timeline: "6-10 months",
              keySteps: [
                "Market analysis and competitor research",
                "Product development and testing",
                "Strategic partnerships",
                "Marketing campaign launch",
                "Performance monitoring and scaling",
              ],
            },
            financials: {
              initialInvestment: Math.floor(budgetNum * 0.6),
              monthlyOperatingCost: Math.floor(budgetNum * 0.08),
              projectedMonthlyRevenue: Math.floor(budgetNum * 0.15),
              breakEvenMonths: 6,
              costBreakdown: {
                materials: Math.floor(budgetNum * 0.03),
                labor: Math.floor(budgetNum * 0.035),
                marketing: Math.floor(budgetNum * 0.02),
                overhead: Math.floor(budgetNum * 0.012),
                other: Math.floor(budgetNum * 0.008),
              },
            },
            operations: {
              staffingPlan: [
                { role: "Business Manager", count: 1, salary: 35000 },
                { role: "Marketing Specialist", count: 1, salary: 25000 },
                { role: "Operations Staff", count: 2, salary: 20000 },
              ],
              suppliers: [`Regional ${industry} suppliers`, "Technology partners"],
              keyProcesses: ["Digital marketing", "Supply chain optimization", "Customer analytics"],
            },
            risks: ["Market volatility", "Scaling challenges", "Resource constraints"],
            opportunities: ["Digital transformation trends", "Export potential", "Strategic partnerships"],
            sustainabilityScore: 7,
          },
          {
            id: "fallback-aggressive",
            name: "Aggressive Market Capture",
            description: `A high-growth, high-risk strategy for rapid ${idea} expansion`,
            riskLevel: "aggressive",
            marketEntry: {
              strategy: "Rapid market penetration with significant investment",
              timeline: "4-8 months",
              keySteps: [
                "Immediate market entry",
                "Large-scale marketing blitz",
                "Rapid team scaling",
                "Multi-channel distribution",
                "Aggressive pricing strategy",
              ],
            },
            financials: {
              initialInvestment: Math.floor(budgetNum * 0.8),
              monthlyOperatingCost: Math.floor(budgetNum * 0.12),
              projectedMonthlyRevenue: Math.floor(budgetNum * 0.25),
              breakEvenMonths: 4,
              costBreakdown: {
                materials: Math.floor(budgetNum * 0.04),
                labor: Math.floor(budgetNum * 0.05),
                marketing: Math.floor(budgetNum * 0.04),
                overhead: Math.floor(budgetNum * 0.02),
                other: Math.floor(budgetNum * 0.01),
              },
            },
            operations: {
              staffingPlan: [
                { role: "CEO/Founder", count: 1, salary: 50000 },
                { role: "Marketing Manager", count: 1, salary: 35000 },
                { role: "Sales Team", count: 3, salary: 25000 },
                { role: "Operations Staff", count: 3, salary: 22000 },
              ],
              suppliers: ["Multiple supplier partnerships", "Technology integrators", "Logistics partners"],
              keyProcesses: ["Automated operations", "Performance tracking", "Rapid iteration"],
            },
            risks: ["High capital requirements", "Market saturation risk", "Operational complexity"],
            opportunities: ["First-mover advantage", "Market leadership", "Rapid scaling potential"],
            sustainabilityScore: 6,
          },
        ],
      })
    }
  } catch (error) {
    console.error("[v0] Error generating business models:", error)
    return NextResponse.json({ error: "Failed to generate business models" }, { status: 500 })
  }
}
