import { type NextRequest, NextResponse } from "next/server"
import { webScraper, type ScrapingConfig } from "@/lib/web-scraper"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { businessType, industry, location, countryCode, dataTypes } = body

    console.log("[v0] Starting data scraping for:", { businessType, industry, location, dataTypes })

    if (!businessType || !location || !dataTypes || !Array.isArray(dataTypes)) {
      return NextResponse.json(
        { error: "Missing required fields: businessType, location, and dataTypes array" },
        { status: 400 },
      )
    }

    const config: ScrapingConfig = {
      businessType,
      industry: industry || businessType,
      location,
      countryCode: countryCode || "US",
      dataTypes,
    }

    // Scrape industry data
    const industryData = await webScraper.scrapeIndustryData(config)
    console.log("[v0] Scraped industry data sources:", industryData.length)

    // Scrape competitor data if requested
    let competitorData = []
    if (dataTypes.includes("competitor")) {
      competitorData = await webScraper.scrapeCompetitorData(config)
      console.log("[v0] Scraped competitor data sources:", competitorData.length)
    }

    const allData = [...industryData, ...competitorData]

    console.log("[v0] Total scraped data sources:", allData.length)

    return NextResponse.json({
      success: true,
      data: allData,
      summary: {
        totalSources: allData.length,
        dataTypes: [...new Set(allData.map((d) => d.type))],
        averageConfidence: allData.reduce((sum, d) => sum + d.confidence, 0) / allData.length,
        scrapedAt: new Date().toISOString(),
      },
    })
  } catch (error) {
    console.error("Data scraping error:", error)
    return NextResponse.json(
      { error: "Failed to scrape data", details: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    )
  }
}
