"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Zap, Mail, Lock, Mic } from "lucide-react"
import Link from "next/link"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isVoiceLogin, setIsVoiceLogin] = useState(false)
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Demo login - just simulate API call
    setTimeout(() => {
      // Store demo user data
      localStorage.setItem(
        "bizpilot_user",
        JSON.stringify({
          email,
          name: email.split("@")[0],
          isAuthenticated: true,
          loginTime: new Date().toISOString(),
        }),
      )

      setIsLoading(false)
      router.push("/onboarding")
    }, 1500)
  }

  const handleVoiceLogin = () => {
    setIsVoiceLogin(true)

    // Demo voice recognition
    if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition
      const recognition = new SpeechRecognition()

      recognition.onstart = () => {
        console.log("[v0] Voice recognition started")
      }

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript.toLowerCase()
        console.log("[v0] Voice input:", transcript)

        // Demo: if they say something like "login as john" or just their name
        if (transcript.includes("login") || transcript.includes("john") || transcript.includes("demo")) {
          setEmail("demo@bizpilot.com")
          setPassword("demo123")

          // Auto-login after voice input
          setTimeout(() => {
            localStorage.setItem(
              "bizpilot_user",
              JSON.stringify({
                email: "demo@bizpilot.com",
                name: "Demo User",
                isAuthenticated: true,
                loginTime: new Date().toISOString(),
                voiceLogin: true,
              }),
            )
            router.push("/onboarding")
          }, 1000)
        }
        setIsVoiceLogin(false)
      }

      recognition.onerror = () => {
        setIsVoiceLogin(false)
        // Fallback to demo login
        setEmail("demo@bizpilot.com")
        setPassword("demo123")
      }

      recognition.start()
    } else {
      // Fallback for browsers without speech recognition
      setIsVoiceLogin(false)
      setEmail("demo@bizpilot.com")
      setPassword("demo123")
    }
  }

  const handleOAuthLogin = (provider: string) => {
    setIsLoading(true)

    // Demo OAuth - simulate redirect
    setTimeout(() => {
      localStorage.setItem(
        "bizpilot_user",
        JSON.stringify({
          email: `demo@${provider}.com`,
          name: `${provider} User`,
          isAuthenticated: true,
          loginTime: new Date().toISOString(),
          provider,
        }),
      )

      setIsLoading(false)
      router.push("/onboarding")
    }, 2000)
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-accent-foreground" />
            </div>
            <span className="text-xl font-bold">BizPilot</span>
          </div>
          <CardTitle className="text-2xl">Welcome back</CardTitle>
          <CardDescription>Sign in to your account to continue</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? "Signing in..." : "Sign in"}
            </Button>
          </form>

          <div className="space-y-3">
            <Button
              variant="outline"
              className="w-full bg-transparent"
              onClick={handleVoiceLogin}
              disabled={isVoiceLogin}
            >
              <Mic className="w-4 h-4 mr-2" />
              {isVoiceLogin ? "Listening..." : "Sign in with Voice"}
            </Button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <Separator className="w-full" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">Or continue with</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Button variant="outline" onClick={() => handleOAuthLogin("google")} disabled={isLoading}>
                Google
              </Button>
              <Button variant="outline" onClick={() => handleOAuthLogin("linkedin")} disabled={isLoading}>
                LinkedIn
              </Button>
            </div>
          </div>

          <div className="text-center text-sm">
            <span className="text-muted-foreground">Don't have an account? </span>
            <Link href="/auth/signup" className="text-accent hover:underline">
              Sign up
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
