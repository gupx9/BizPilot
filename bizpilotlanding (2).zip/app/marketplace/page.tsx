"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search, Star, Download, Heart, ArrowLeft, Zap, MessageSquare, Share } from "lucide-react"

// Mock business template data
const businessTemplates = [
  {
    id: 1,
    title: "E-commerce Dropshipping Store",
    description:
      "Complete business plan for starting a dropshipping business with supplier connections and marketing strategies",
    category: "E-commerce",
    rating: 4.8,
    downloads: 1247,
    price: "Free",
    author: "Sarah Chen",
    tags: ["dropshipping", "e-commerce", "marketing", "suppliers"],
    revenue: "$50K-100K",
    timeline: "3-6 months",
    difficulty: "Beginner",
  },
  {
    id: 2,
    title: "Local Service Business Blueprint",
    description:
      "Proven framework for launching home services business including pricing, operations, and customer acquisition",
    category: "Services",
    rating: 4.9,
    downloads: 892,
    price: "Pro",
    author: "Mike Rodriguez",
    tags: ["local business", "services", "operations", "pricing"],
    revenue: "$75K-150K",
    timeline: "2-4 months",
    difficulty: "Intermediate",
  },
  {
    id: 3,
    title: "SaaS Startup Playbook",
    description: "Comprehensive guide to building and scaling a SaaS product from MVP to $1M ARR",
    category: "Technology",
    rating: 4.7,
    downloads: 2156,
    price: "Pro",
    author: "Alex Kim",
    tags: ["saas", "technology", "scaling", "mvp"],
    revenue: "$100K-500K",
    timeline: "6-12 months",
    difficulty: "Advanced",
  },
  {
    id: 4,
    title: "Food Truck Business Plan",
    description:
      "Step-by-step guide to starting a profitable food truck including permits, locations, and menu planning",
    category: "Food & Beverage",
    rating: 4.6,
    downloads: 634,
    price: "Free",
    author: "Maria Santos",
    tags: ["food truck", "permits", "locations", "menu"],
    revenue: "$40K-80K",
    timeline: "2-3 months",
    difficulty: "Beginner",
  },
  {
    id: 5,
    title: "Digital Marketing Agency",
    description:
      "Complete framework for starting a digital marketing agency with client acquisition and service delivery",
    category: "Marketing",
    rating: 4.8,
    downloads: 1543,
    price: "Free",
    author: "David Park",
    tags: ["marketing", "agency", "clients", "services"],
    revenue: "$60K-200K",
    timeline: "1-3 months",
    difficulty: "Intermediate",
  },
  {
    id: 6,
    title: "Subscription Box Business",
    description:
      "Detailed plan for launching a subscription box service including sourcing, fulfillment, and retention",
    category: "E-commerce",
    rating: 4.5,
    downloads: 789,
    price: "Pro",
    author: "Jennifer Liu",
    tags: ["subscription", "fulfillment", "retention", "sourcing"],
    revenue: "$30K-120K",
    timeline: "4-6 months",
    difficulty: "Intermediate",
  },
]

export default function MarketplacePage() {
  const [userData, setUserData] = useState<any>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [filteredTemplates, setFilteredTemplates] = useState(businessTemplates)
  const router = useRouter()

  useEffect(() => {
    // Check authentication
    const user = localStorage.getItem("bizpilot_user")
    if (!user) {
      router.push("/auth/login")
      return
    }
    setUserData(JSON.parse(user))
  }, [router])

  useEffect(() => {
    // Filter templates based on search and category
    let filtered = businessTemplates

    if (searchTerm) {
      filtered = filtered.filter(
        (template) =>
          template.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          template.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          template.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase())),
      )
    }

    if (selectedCategory !== "all") {
      filtered = filtered.filter((template) => template.category === selectedCategory)
    }

    setFilteredTemplates(filtered)
  }, [searchTerm, selectedCategory])

  const categories = ["all", ...Array.from(new Set(businessTemplates.map((t) => t.category)))]

  const handleDownloadTemplate = (templateId: number) => {
    // Mock download functionality
    const template = businessTemplates.find((t) => t.id === templateId)
    if (template) {
      // Store downloaded template
      const downloads = JSON.parse(localStorage.getItem("bizpilot_downloads") || "[]")
      downloads.push({
        ...template,
        downloadedAt: new Date().toISOString(),
        userId: userData.email,
      })
      localStorage.setItem("bizpilot_downloads", JSON.stringify(downloads))

      // Show success message (in real app, would show toast)
      alert(`Downloaded: ${template.title}`)
    }
  }

  if (!userData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">Loading...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="sm" onClick={() => router.push("/dashboard")}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-accent-foreground" />
              </div>
              <span className="text-xl font-bold">BizPilot</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Badge variant="secondary">Free Plan</Badge>
            <Button variant="outline" size="sm">
              Upgrade to Pro
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Business Template Marketplace</h1>
          <p className="text-muted-foreground">
            Discover and download proven business templates shared by the community
          </p>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search templates..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
              >
                {category === "all" ? "All" : category}
              </Button>
            ))}
          </div>
        </div>

        {/* Templates Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {filteredTemplates.map((template) => (
            <Card key={template.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between mb-2">
                  <Badge variant="secondary">{template.category}</Badge>
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium">{template.rating}</span>
                  </div>
                </div>
                <CardTitle className="text-lg">{template.title}</CardTitle>
                <p className="text-sm text-muted-foreground line-clamp-2">{template.description}</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Revenue Potential:</span>
                    <span className="font-medium">{template.revenue}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Timeline:</span>
                    <span className="font-medium">{template.timeline}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Difficulty:</span>
                    <Badge
                      variant={
                        template.difficulty === "Beginner"
                          ? "secondary"
                          : template.difficulty === "Intermediate"
                            ? "default"
                            : "destructive"
                      }
                    >
                      {template.difficulty}
                    </Badge>
                  </div>

                  <div className="flex flex-wrap gap-1 mt-3">
                    {template.tags.slice(0, 3).map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t">
                    <div className="text-sm text-muted-foreground">by {template.author}</div>
                    <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                      <Download className="w-3 h-3" />
                      <span>{template.downloads}</span>
                    </div>
                  </div>

                  <div className="flex space-x-2 pt-2">
                    <Button
                      className="flex-1"
                      size="sm"
                      onClick={() => handleDownloadTemplate(template.id)}
                      disabled={template.price === "Pro" && userData.plan !== "pro"}
                    >
                      <Download className="w-4 h-4 mr-2" />
                      {template.price === "Pro" ? "Pro Only" : "Download"}
                    </Button>
                    <Button variant="outline" size="sm">
                      <Heart className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" size="sm">
                      <Share className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Community Feedback Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <MessageSquare className="w-5 h-5 mr-2" />
              Share Your Template
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Help the community by sharing your successful business templates
            </p>
          </CardHeader>
          <CardContent>
            <div className="bg-muted/20 rounded-lg p-6 text-center">
              <h3 className="font-semibold mb-2">Contribute to the Community</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Share your business templates and help other entrepreneurs succeed
              </p>
              <Button>
                <Share className="w-4 h-4 mr-2" />
                Submit Template
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
