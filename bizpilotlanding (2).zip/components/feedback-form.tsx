"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Star, MessageSquare, Send } from "lucide-react"

interface FeedbackFormProps {
  onSubmit: (feedback: any) => void
  onClose: () => void
}

export function FeedbackForm({ onSubmit, onClose }: FeedbackFormProps) {
  const [rating, setRating] = useState(0)
  const [category, setCategory] = useState("general")
  const [feedback, setFeedback] = useState("")
  const [email, setEmail] = useState("")

  const categories = [
    { id: "general", label: "General Feedback" },
    { id: "features", label: "Feature Request" },
    { id: "bug", label: "Bug Report" },
    { id: "ui", label: "UI/UX Improvement" },
    { id: "ai", label: "AI Suggestions" },
  ]

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit({
      rating,
      category,
      feedback,
      email,
      timestamp: new Date().toISOString(),
    })
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <Card className="w-full max-w-lg mx-4">
        <CardHeader>
          <CardTitle className="flex items-center">
            <MessageSquare className="w-5 h-5 mr-2" />
            Share Your Feedback
          </CardTitle>
          <p className="text-sm text-muted-foreground">Help us improve BizPilot with your suggestions and ideas</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Rating */}
            <div>
              <label className="text-sm font-medium mb-2 block">How would you rate your experience?</label>
              <div className="flex space-x-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button key={star} type="button" onClick={() => setRating(star)} className="p-1">
                    <Star
                      className={`w-6 h-6 ${
                        star <= rating ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground"
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Category */}
            <div>
              <label className="text-sm font-medium mb-2 block">Feedback Category</label>
              <div className="flex flex-wrap gap-2">
                {categories.map((cat) => (
                  <Badge
                    key={cat.id}
                    variant={category === cat.id ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => setCategory(cat.id)}
                  >
                    {cat.label}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Feedback Text */}
            <div>
              <label className="text-sm font-medium mb-2 block">Your Feedback</label>
              <Textarea
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                placeholder="Tell us what you think, what features you'd like to see, or any issues you've encountered..."
                className="min-h-[100px]"
                required
              />
            </div>

            {/* Email (Optional) */}
            <div>
              <label className="text-sm font-medium mb-2 block">Email (Optional)</label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
              />
              <p className="text-xs text-muted-foreground mt-1">We'll only use this to follow up on your feedback</p>
            </div>

            {/* Submit Buttons */}
            <div className="flex space-x-3 pt-4">
              <Button type="submit" className="flex-1">
                <Send className="w-4 h-4 mr-2" />
                Submit Feedback
              </Button>
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
