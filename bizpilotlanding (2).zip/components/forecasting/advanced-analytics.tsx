"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle, Activity, Target } from "lucide-react"
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts"

interface AnalyticsProps {
  forecastData: {
    demand: number[]
    production: number[]
    inventory: number[]
    staffing: number[]
    confidence: number
    factors: string[]
    recommendations: string[]
  }
  metadata: {
    location: string
    businessType: string
    timeHorizon: number
  }
}

export function AdvancedAnalytics({ forecastData, metadata }: AnalyticsProps) {
  // Calculate trend analysis
  const calculateTrend = (data: number[]) => {
    if (data.length < 2) return 0
    const firstHalf = data.slice(0, Math.floor(data.length / 2))
    const secondHalf = data.slice(Math.floor(data.length / 2))
    const firstAvg = firstHalf.reduce((a, b) => a + b, 0) / firstHalf.length
    const secondAvg = secondHalf.reduce((a, b) => a + b, 0) / secondHalf.length
    return ((secondAvg - firstAvg) / firstAvg) * 100
  }

  const demandTrend = calculateTrend(forecastData.demand)
  const productionTrend = calculateTrend(forecastData.production)
  const inventoryTrend = calculateTrend(forecastData.inventory)
  const staffingTrend = calculateTrend(forecastData.staffing)

  // Risk assessment data
  const riskData = [
    { name: "Low Risk", value: 60, color: "#10b981" },
    { name: "Medium Risk", value: 30, color: "#f59e0b" },
    { name: "High Risk", value: 10, color: "#ef4444" },
  ]

  // Performance metrics
  const performanceData = [
    { metric: "Demand Accuracy", current: 85, target: 90 },
    { metric: "Production Efficiency", current: 78, target: 85 },
    { metric: "Inventory Turnover", current: 92, target: 95 },
    { metric: "Staff Utilization", current: 88, target: 90 },
  ]

  const TrendIcon = ({ trend }: { trend: number }) => {
    if (trend > 5) return <TrendingUp className="w-4 h-4 text-green-500" />
    if (trend < -5) return <TrendingDown className="w-4 h-4 text-red-500" />
    return <Activity className="w-4 h-4 text-yellow-500" />
  }

  return (
    <div className="space-y-6">
      {/* Trend Analysis */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="w-5 h-5 mr-2" />
            Trend Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 border rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Demand</span>
                <TrendIcon trend={demandTrend} />
              </div>
              <div className="text-2xl font-bold">{demandTrend.toFixed(1)}%</div>
              <p className="text-xs text-muted-foreground">vs previous period</p>
            </div>
            <div className="p-4 border rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Production</span>
                <TrendIcon trend={productionTrend} />
              </div>
              <div className="text-2xl font-bold">{productionTrend.toFixed(1)}%</div>
              <p className="text-xs text-muted-foreground">vs previous period</p>
            </div>
            <div className="p-4 border rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Inventory</span>
                <TrendIcon trend={inventoryTrend} />
              </div>
              <div className="text-2xl font-bold">{inventoryTrend.toFixed(1)}%</div>
              <p className="text-xs text-muted-foreground">vs previous period</p>
            </div>
            <div className="p-4 border rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Staffing</span>
                <TrendIcon trend={staffingTrend} />
              </div>
              <div className="text-2xl font-bold">{staffingTrend.toFixed(1)}%</div>
              <p className="text-xs text-muted-foreground">vs previous period</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Risk Assessment */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2" />
              Risk Assessment
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={riskData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {riskData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-center space-x-4 mt-4">
              {riskData.map((item, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                  <span className="text-sm">{item.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Target className="w-5 h-5 mr-2" />
              Performance vs Targets
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {performanceData.map((item, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>{item.metric}</span>
                    <span>
                      {item.current}% / {item.target}%
                    </span>
                  </div>
                  <Progress value={(item.current / item.target) * 100} className="h-2" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Current: {item.current}%</span>
                    <span>Target: {item.target}%</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Confidence Indicators */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <CheckCircle className="w-5 h-5 mr-2" />
            Forecast Confidence Breakdown
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 border rounded-lg">
              <div className="text-3xl font-bold text-green-500 mb-2">{Math.round(forecastData.confidence * 100)}%</div>
              <p className="text-sm text-muted-foreground">Overall Confidence</p>
              <Badge
                variant={
                  forecastData.confidence > 0.8
                    ? "default"
                    : forecastData.confidence > 0.6
                      ? "secondary"
                      : "destructive"
                }
                className="mt-2"
              >
                {forecastData.confidence > 0.8 ? "High" : forecastData.confidence > 0.6 ? "Medium" : "Low"}
              </Badge>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-3xl font-bold text-blue-500 mb-2">{forecastData.factors.length}</div>
              <p className="text-sm text-muted-foreground">Data Sources</p>
              <Badge variant="outline" className="mt-2">
                Multi-factor
              </Badge>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-3xl font-bold text-purple-500 mb-2">{metadata.timeHorizon}</div>
              <p className="text-sm text-muted-foreground">Months Ahead</p>
              <Badge variant="outline" className="mt-2">
                {metadata.timeHorizon <= 6 ? "Short-term" : metadata.timeHorizon <= 12 ? "Medium-term" : "Long-term"}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Seasonal Patterns */}
      <Card>
        <CardHeader>
          <CardTitle>Seasonal Pattern Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={forecastData.demand.map((value, index) => ({
                  month: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][
                    index % 12
                  ],
                  demand: value,
                  seasonal: value * (1 + Math.sin((index * Math.PI) / 6) * 0.2), // Mock seasonal adjustment
                }))}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="demand" fill="#3b82f6" name="Forecasted Demand" />
                <Bar dataKey="seasonal" fill="#10b981" name="Seasonal Adjusted" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
