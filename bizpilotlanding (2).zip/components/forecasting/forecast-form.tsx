"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Loader2, TrendingUp } from "lucide-react"

interface ForecastFormProps {
  onSubmit: (data: ForecastFormData) => void
  loading?: boolean
}

export interface ForecastFormData {
  location: string
  countryCode: string
  businessType: string
  timeHorizon: number
  historicalData: string
  businessContext: string
}

const businessTypes = [
  { value: "retail", label: "Retail & E-commerce" },
  { value: "restaurant", label: "Restaurant & Food Service" },
  { value: "manufacturing", label: "Manufacturing" },
  { value: "services", label: "Professional Services" },
  { value: "healthcare", label: "Healthcare" },
  { value: "technology", label: "Technology" },
  { value: "construction", label: "Construction" },
  { value: "agriculture", label: "Agriculture" },
  { value: "logistics", label: "Logistics & Transportation" },
  { value: "other", label: "Other" },
]

const countries = [
  { value: "US", label: "United States" },
  { value: "BD", label: "Bangladesh" },
  { value: "IN", label: "India" },
  { value: "GB", label: "United Kingdom" },
  { value: "DE", label: "Germany" },
  { value: "FR", label: "France" },
  { value: "JP", label: "Japan" },
  { value: "CN", label: "China" },
  { value: "CA", label: "Canada" },
  { value: "AU", label: "Australia" },
]

export function ForecastForm({ onSubmit, loading = false }: ForecastFormProps) {
  const [formData, setFormData] = useState<ForecastFormData>({
    location: "",
    countryCode: "",
    businessType: "",
    timeHorizon: 12,
    historicalData: "",
    businessContext: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
  }

  const updateField = (field: keyof ForecastFormData, value: string | number) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-accent" />
          Generate Operational Forecast
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="location">Business Location</Label>
              <Input
                id="location"
                placeholder="e.g., New York, Dhaka, London"
                value={formData.location}
                onChange={(e) => updateField("location", e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="country">Country</Label>
              <Select value={formData.countryCode} onValueChange={(value) => updateField("countryCode", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select country" />
                </SelectTrigger>
                <SelectContent>
                  {countries.map((country) => (
                    <SelectItem key={country.value} value={country.value}>
                      {country.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="businessType">Business Type</Label>
              <Select value={formData.businessType} onValueChange={(value) => updateField("businessType", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select business type" />
                </SelectTrigger>
                <SelectContent>
                  {businessTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="timeHorizon">Forecast Period (Months)</Label>
              <Select
                value={formData.timeHorizon.toString()}
                onValueChange={(value) => updateField("timeHorizon", Number.parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3">3 Months</SelectItem>
                  <SelectItem value="6">6 Months</SelectItem>
                  <SelectItem value="12">12 Months</SelectItem>
                  <SelectItem value="18">18 Months</SelectItem>
                  <SelectItem value="24">24 Months</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="historicalData">Historical Data (Optional)</Label>
            <Textarea
              id="historicalData"
              placeholder="Paste historical sales, production, or operational data (CSV, JSON, or text format)"
              value={formData.historicalData}
              onChange={(e) => updateField("historicalData", e.target.value)}
              rows={4}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="businessContext">Business Context (Optional)</Label>
            <Textarea
              id="businessContext"
              placeholder="Describe your business model, key challenges, seasonal patterns, or specific factors to consider"
              value={formData.businessContext}
              onChange={(e) => updateField("businessContext", e.target.value)}
              rows={3}
            />
          </div>

          <Button
            type="submit"
            className="w-full"
            disabled={loading || !formData.location || !formData.countryCode || !formData.businessType}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating Forecast...
              </>
            ) : (
              "Generate Forecast"
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
