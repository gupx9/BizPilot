"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AlertTriangle, CheckCircle, Info, Bell } from "lucide-react"

interface AlertsProps {
  forecastData: {
    demand: number[]
    production: number[]
    inventory: number[]
    staffing: number[]
    confidence: number
    factors: string[]
    recommendations: string[]
  }
}

export function ForecastAlerts({ forecastData }: AlertsProps) {
  // Generate alerts based on forecast data
  const generateAlerts = () => {
    const alerts = []

    // Check for demand spikes
    const maxDemand = Math.max(...forecastData.demand)
    const avgDemand = forecastData.demand.reduce((a, b) => a + b, 0) / forecastData.demand.length
    if (maxDemand > avgDemand * 1.5) {
      alerts.push({
        type: "warning",
        title: "High Demand Spike Expected",
        message: `Demand is forecasted to peak at ${maxDemand.toFixed(0)} units, ${((maxDemand / avgDemand - 1) * 100).toFixed(0)}% above average.`,
        action: "Increase production capacity",
        priority: "high",
      })
    }

    // Check for inventory shortfalls
    const minInventory = Math.min(...forecastData.inventory)
    if (minInventory < 30) {
      alerts.push({
        type: "error",
        title: "Inventory Shortage Risk",
        message: `Inventory levels may drop to ${minInventory.toFixed(0)} units, below recommended threshold.`,
        action: "Increase stock orders",
        priority: "critical",
      })
    }

    // Check for staffing misalignment
    const staffingVariance = Math.max(...forecastData.staffing) - Math.min(...forecastData.staffing)
    if (staffingVariance > 30) {
      alerts.push({
        type: "warning",
        title: "Staffing Level Fluctuation",
        message: `Staffing requirements vary by ${staffingVariance.toFixed(0)} units across the forecast period.`,
        action: "Plan flexible staffing",
        priority: "medium",
      })
    }

    // Check for production overcapacity
    const maxProduction = Math.max(...forecastData.production)
    const maxDemandProduction = Math.max(...forecastData.demand)
    if (maxProduction > maxDemandProduction * 1.3) {
      alerts.push({
        type: "info",
        title: "Production Overcapacity",
        message: `Production capacity exceeds demand by ${((maxProduction / maxDemandProduction - 1) * 100).toFixed(0)}%.`,
        action: "Optimize production schedule",
        priority: "low",
      })
    }

    // Low confidence alert
    if (forecastData.confidence < 0.7) {
      alerts.push({
        type: "warning",
        title: "Low Forecast Confidence",
        message: `Forecast confidence is ${(forecastData.confidence * 100).toFixed(0)}%. Consider gathering more historical data.`,
        action: "Improve data quality",
        priority: "medium",
      })
    }

    return alerts
  }

  const alerts = generateAlerts()

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "error":
        return <AlertTriangle className="w-5 h-5 text-red-500" />
      case "warning":
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />
      case "info":
        return <Info className="w-5 h-5 text-blue-500" />
      default:
        return <CheckCircle className="w-5 h-5 text-green-500" />
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical":
        return "destructive"
      case "high":
        return "destructive"
      case "medium":
        return "secondary"
      case "low":
        return "outline"
      default:
        return "outline"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Bell className="w-5 h-5 mr-2" />
          Smart Alerts & Recommendations
        </CardTitle>
      </CardHeader>
      <CardContent>
        {alerts.length > 0 ? (
          <div className="space-y-4">
            {alerts.map((alert, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-start space-x-3">
                  {getAlertIcon(alert.type)}
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{alert.title}</h4>
                      <Badge variant={getPriorityColor(alert.priority) as any}>{alert.priority}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{alert.message}</p>
                    <Button size="sm" variant="outline">
                      {alert.action}
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">All Systems Optimal</h3>
            <p className="text-muted-foreground">No critical alerts detected in your forecast.</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
