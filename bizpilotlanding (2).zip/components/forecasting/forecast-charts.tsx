"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts"
import { TrendingUp, Users, Package, Factory, AlertTriangle } from "lucide-react"

interface ForecastResult {
  demand: number[]
  production: number[]
  inventory: number[]
  staffing: number[]
  confidence: number
  factors: string[]
  recommendations: string[]
}

interface ForecastChartsProps {
  forecast: ForecastResult
  timeHorizon: number
  insights?: string[]
}

export function ForecastCharts({ forecast, timeHorizon, insights = [] }: ForecastChartsProps) {
  // Generate month labels
  const generateMonthLabels = (months: number) => {
    const labels = []
    const currentDate = new Date()
    for (let i = 0; i < months; i++) {
      const date = new Date(currentDate.getFullYear(), currentDate.getMonth() + i, 1)
      labels.push(date.toLocaleDateString("en-US", { month: "short", year: "2-digit" }))
    }
    return labels
  }

  const monthLabels = generateMonthLabels(timeHorizon)

  // Prepare chart data
  const chartData = monthLabels.map((month, index) => ({
    month,
    demand: forecast.demand[index] || 0,
    production: forecast.production[index] || 0,
    inventory: forecast.inventory[index] || 0,
    staffing: forecast.staffing[index] || 0,
  }))

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return "bg-green-500"
    if (confidence >= 0.6) return "bg-yellow-500"
    return "bg-red-500"
  }

  const getConfidenceText = (confidence: number) => {
    if (confidence >= 0.8) return "High Confidence"
    if (confidence >= 0.6) return "Medium Confidence"
    return "Low Confidence"
  }

  return (
    <div className="space-y-6">
      {/* Confidence and Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Forecast Confidence</p>
                <p className="text-2xl font-bold">{Math.round(forecast.confidence * 100)}%</p>
              </div>
              <div className={`w-3 h-3 rounded-full ${getConfidenceColor(forecast.confidence)}`} />
            </div>
            <Badge variant="secondary" className="mt-2">
              {getConfidenceText(forecast.confidence)}
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Demand</p>
                <p className="text-2xl font-bold">
                  {Math.round(forecast.demand.reduce((a, b) => a + b, 0) / forecast.demand.length)}
                </p>
              </div>
              <TrendingUp className="w-5 h-5 text-accent" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Production</p>
                <p className="text-2xl font-bold">
                  {Math.round(forecast.production.reduce((a, b) => a + b, 0) / forecast.production.length)}
                </p>
              </div>
              <Factory className="w-5 h-5 text-accent" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Staffing</p>
                <p className="text-2xl font-bold">
                  {Math.round(forecast.staffing.reduce((a, b) => a + b, 0) / forecast.staffing.length)}
                </p>
              </div>
              <Users className="w-5 h-5 text-accent" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Forecast Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Operational Forecast Trends</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="demand" stroke="hsl(var(--chart-1))" strokeWidth={2} name="Demand" />
              <Line
                type="monotone"
                dataKey="production"
                stroke="hsl(var(--chart-2))"
                strokeWidth={2}
                name="Production"
              />
              <Line type="monotone" dataKey="inventory" stroke="hsl(var(--chart-3))" strokeWidth={2} name="Inventory" />
              <Line type="monotone" dataKey="staffing" stroke="hsl(var(--chart-4))" strokeWidth={2} name="Staffing" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Individual Metric Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Demand Forecast
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="demand" fill="hsl(var(--chart-1))" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="w-4 h-4" />
              Inventory Levels
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="inventory" fill="hsl(var(--chart-3))" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Key Factors and Recommendations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Key Influencing Factors
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {forecast.factors.map((factor, index) => (
                <Badge key={index} variant="outline" className="mr-2 mb-2">
                  {factor.replace(/_/g, " ").toUpperCase()}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recommendations</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {forecast.recommendations.map((rec, index) => (
                <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                  <span className="w-1.5 h-1.5 bg-accent rounded-full mt-2 flex-shrink-0" />
                  {rec}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* AI Insights */}
      {insights.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>AI-Generated Business Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {insights.map((insight, index) => (
                <div key={index} className="p-3 bg-muted rounded-lg">
                  <p className="text-sm">{insight}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
