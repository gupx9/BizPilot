"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Crown, Lock, Sparkles } from "lucide-react"
import { useRouter } from "next/navigation"

interface PremiumGateProps {
  feature: string
  description: string
  children?: React.ReactNode
}

export function PremiumGate({ feature, description, children }: PremiumGateProps) {
  const router = useRouter()

  return (
    <Card className="border-accent/50 bg-accent/5 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-accent/10 to-transparent" />
      <CardContent className="p-6 relative">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center mb-2">
              <Lock className="w-4 h-4 mr-2 text-accent" />
              <Badge variant="secondary" className="bg-accent/20 text-accent-foreground">
                Premium Feature
              </Badge>
            </div>
            <h3 className="font-semibold mb-2">{feature}</h3>
            <p className="text-sm text-muted-foreground mb-4">{description}</p>
            <Button onClick={() => router.push("/premium")} className="mb-4">
              <Crown className="w-4 h-4 mr-2" />
              Upgrade to Pro
            </Button>
          </div>
          <div className="text-6xl opacity-10">
            <Sparkles />
          </div>
        </div>
        {children && (
          <div className="relative">
            <div className="absolute inset-0 bg-background/80 backdrop-blur-sm rounded-lg flex items-center justify-center">
              <div className="text-center">
                <Lock className="w-8 h-8 text-accent mx-auto mb-2" />
                <p className="text-sm font-medium">Upgrade to unlock</p>
              </div>
            </div>
            <div className="opacity-30">{children}</div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export default PremiumGate
