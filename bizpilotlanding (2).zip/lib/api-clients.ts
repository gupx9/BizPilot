import { groq } from "@ai-sdk/groq"

// Groq Client with browser support
export const groqClient = new groq({
  apiKey: process.env.GROQ_API_KEY || "your-groq-api-key",
  dangerouslyAllowBrowser: true,
})

// OpenWeatherMap API client - SERVER SIDE ONLY
export class WeatherAPI {
  private apiKey: string
  private baseUrl = "https://api.openweathermap.org/data/2.5"

  constructor() {
    this.apiKey = process.env.OPENWEATHERMAP_API_KEY || "e1dde7c622ffbf562bb40da85092e2d8"
  }

  async getCurrentWeather(city: string) {
    const response = await fetch(`${this.baseUrl}/weather?q=${city}&appid=${this.apiKey}&units=metric`)
    return response.json()
  }

  async getForecast(city: string, days = 5) {
    const response = await fetch(`${this.baseUrl}/forecast?q=${city}&appid=${this.apiKey}&units=metric&cnt=${days * 8}`)
    return response.json()
  }

  async getHistoricalWeather(lat: number, lon: number, dt: number) {
    const response = await fetch(
      `${this.baseUrl}/onecall/timemachine?lat=${lat}&lon=${lon}&dt=${dt}&appid=${this.apiKey}`,
    )
    return response.json()
  }
}

// World Bank API client
export class WorldBankAPI {
  private baseUrl = "https://api.worldbank.org/v2"

  async getEconomicIndicators(countryCode: string, indicator: string, year?: string) {
    const yearParam = year ? `/${year}` : ""
    const response = await fetch(
      `${this.baseUrl}/country/${countryCode}/indicator/${indicator}${yearParam}?format=json&per_page=100`,
    )
    return response.json()
  }

  async getGDPData(countryCode: string, years = 5) {
    return this.getEconomicIndicators(countryCode, "NY.GDP.MKTP.CD")
  }

  async getInflationData(countryCode: string) {
    return this.getEconomicIndicators(countryCode, "FP.CPI.TOTL.ZG")
  }

  async getUnemploymentData(countryCode: string) {
    return this.getEconomicIndicators(countryCode, "SL.UEM.TOTL.ZS")
  }

  async getPopulationData(countryCode: string) {
    return this.getEconomicIndicators(countryCode, "SP.POP.TOTL")
  }
}

// Alpha Vantage API client for financial and economic data
export class AlphaVantageAPI {
  private apiKey: string
  private baseUrl = "https://www.alphavantage.co/query"

  constructor() {
    this.apiKey = process.env.ALPHA_VANTAGE_API_KEY || "demo"
  }

  async getStockData(symbol: string, interval = "daily") {
    const functionName = interval === "daily" ? "TIME_SERIES_DAILY" : "TIME_SERIES_INTRADAY"
    const params = new URLSearchParams({
      function: functionName,
      symbol: symbol,
      apikey: this.apiKey,
      outputsize: "compact",
    })

    if (interval !== "daily") {
      params.append("interval", interval)
    }

    const response = await fetch(`${this.baseUrl}?${params}`)
    return response.json()
  }

  async getEconomicIndicator(indicator: string) {
    const params = new URLSearchParams({
      function: indicator,
      apikey: this.apiKey,
    })

    const response = await fetch(`${this.baseUrl}?${params}`)
    return response.json()
  }

  async getRealGDP() {
    return this.getEconomicIndicator("REAL_GDP")
  }

  async getInflationRate() {
    return this.getEconomicIndicator("INFLATION")
  }

  async getUnemploymentRate() {
    return this.getEconomicIndicator("UNEMPLOYMENT")
  }

  async getConsumerSentiment() {
    return this.getEconomicIndicator("CONSUMER_SENTIMENT")
  }

  async getRetailSales() {
    return this.getEconomicIndicator("RETAIL_SALES")
  }

  async getFederalFundsRate() {
    return this.getEconomicIndicator("FEDERAL_FUNDS_RATE")
  }

  async getCPI() {
    return this.getEconomicIndicator("CPI")
  }

  async getForexData(fromCurrency: string, toCurrency: string) {
    const params = new URLSearchParams({
      function: "FX_DAILY",
      from_symbol: fromCurrency,
      to_symbol: toCurrency,
      apikey: this.apiKey,
    })

    const response = await fetch(`${this.baseUrl}?${params}`)
    return response.json()
  }

  async getCommodityData(commodity: string) {
    // Alpha Vantage supports commodities like WTI, BRENT, NATURAL_GAS, COPPER, ALUMINUM, WHEAT, CORN, COTTON, SUGAR, COFFEE
    const params = new URLSearchParams({
      function: commodity.toUpperCase(),
      interval: "monthly",
      apikey: this.apiKey,
    })

    const response = await fetch(`${this.baseUrl}?${params}`)
    return response.json()
  }

  async getSectorPerformance() {
    const params = new URLSearchParams({
      function: "SECTOR",
      apikey: this.apiKey,
    })

    const response = await fetch(`${this.baseUrl}?${params}`)
    return response.json()
  }
}

export const weatherAPI = new WeatherAPI()
export const worldBankAPI = new WorldBankAPI()
export const alphaVantageAPI = new AlphaVantageAPI()
