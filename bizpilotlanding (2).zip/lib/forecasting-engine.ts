import { generateText } from "ai"
import { groq } from "@ai-sdk/groq"
import { alphaVantageAPI, weatherAPI } from "./api-clients"

export interface ForecastingData {
  historical: any[]
  weather: any
  economic: any
  seasonal: any
  external: any
}

export interface ForecastResult {
  demand: number[]
  production: number[]
  inventory: number[]
  staffing: number[]
  confidence: number
  factors: string[]
  recommendations: string[]
}

export class ForecastingEngine {
  private summarizeEconomicData(economic: any): string {
    if (!economic) return "No economic data available"

    const summaries = []

    if (economic.realGDP) {
      const latest = economic.realGDP.data?.[0]
      if (latest) summaries.push(`GDP: ${latest.value}% (${latest.date})`)
    }

    if (economic.inflation) {
      const latest = economic.inflation.data?.[0]
      if (latest) summaries.push(`Inflation: ${latest.value}% (${latest.date})`)
    }

    if (economic.unemployment) {
      const latest = economic.unemployment.data?.[0]
      if (latest) summaries.push(`Unemployment: ${latest.value}% (${latest.date})`)
    }

    if (economic.consumerSentiment) {
      const latest = economic.consumerSentiment.data?.[0]
      if (latest) summaries.push(`Consumer Sentiment: ${latest.value} (${latest.date})`)
    }

    if (economic.retailSales) {
      const latest = economic.retailSales.data?.[0]
      if (latest) summaries.push(`Retail Sales: ${latest.value}% (${latest.date})`)
    }

    if (economic.federalFundsRate) {
      const latest = economic.federalFundsRate.data?.[0]
      if (latest) summaries.push(`Fed Rate: ${latest.value}% (${latest.date})`)
    }

    return summaries.length > 0 ? summaries.join(", ") : "Economic indicators not available"
  }

  private summarizeWeatherData(weather: any): string {
    if (!weather) return "No weather data available"

    const summaries = []

    if (weather.current) {
      summaries.push(
        `Current: ${weather.current.main?.temp || "N/A"}°C, ${weather.current.weather?.[0]?.description || "N/A"}`,
      )
    }

    if (weather.forecast?.list) {
      const avgTemp =
        weather.forecast.list.slice(0, 5).reduce((sum: number, item: any) => sum + (item.main?.temp || 0), 0) / 5
      summaries.push(`5-day avg: ${avgTemp.toFixed(1)}°C`)
    }

    return summaries.length > 0 ? summaries.join(", ") : "Weather data not available"
  }

  private summarizeHistoricalData(historical: any[]): string {
    if (!historical || !Array.isArray(historical) || historical.length === 0) {
      return "No historical data available"
    }

    const recentData = historical.slice(-6) // Last 6 months
    const metrics = ["sales", "inventory", "staffing", "demand"]
    const summaries = []

    metrics.forEach((metric) => {
      const values = recentData.map((item) => item[metric]).filter((val) => val != null)
      if (values.length > 0) {
        const avg = values.reduce((sum, val) => sum + val, 0) / values.length
        const trend = values.length > 1 ? ((values[values.length - 1] - values[0]) / values[0]) * 100 : 0
        summaries.push(`${metric}: avg ${avg.toFixed(1)}, trend ${trend > 0 ? "+" : ""}${trend.toFixed(1)}%`)
      }
    })

    return summaries.length > 0 ? summaries.join("; ") : "Historical trends not available"
  }

  async collectData(location: string, countryCode: string, businessType: string) {
    try {
      console.log("[v0] collectData called with:", { location, countryCode, businessType })

      if (!location || typeof location !== "string" || location.trim().length === 0) {
        throw new Error(`Invalid location parameter: ${location}`)
      }
      if (!countryCode || typeof countryCode !== "string" || countryCode.trim().length === 0) {
        throw new Error(`Invalid countryCode parameter: ${countryCode}`)
      }
      if (!businessType || typeof businessType !== "string" || businessType.trim().length === 0) {
        console.warn("[v0] Invalid businessType, using default:", businessType)
        businessType = "services" // Set a safe default
      }

      const [
        currentWeather,
        weatherForecast,
        realGDP,
        inflationData,
        unemploymentData,
        consumerSentiment,
        retailSales,
        federalFundsRate,
        sectorPerformance,
      ] = await Promise.allSettled([
        weatherAPI.getCurrentWeather(location),
        weatherAPI.getForecast(location, 7),
        alphaVantageAPI.getRealGDP(),
        alphaVantageAPI.getInflationRate(),
        alphaVantageAPI.getUnemploymentRate(),
        alphaVantageAPI.getConsumerSentiment(),
        alphaVantageAPI.getRetailSales(),
        alphaVantageAPI.getFederalFundsRate(),
        alphaVantageAPI.getSectorPerformance(),
      ])

      const seasonalData = this.generateSeasonalPatterns(businessType.trim())

      return {
        weather: {
          current: currentWeather.status === "fulfilled" ? currentWeather.value : null,
          forecast: weatherForecast.status === "fulfilled" ? weatherForecast.value : null,
        },
        economic: {
          realGDP: realGDP.status === "fulfilled" ? realGDP.value : null,
          inflation: inflationData.status === "fulfilled" ? inflationData.value : null,
          unemployment: unemploymentData.status === "fulfilled" ? unemploymentData.value : null,
          consumerSentiment: consumerSentiment.status === "fulfilled" ? consumerSentiment.value : null,
          retailSales: retailSales.status === "fulfilled" ? retailSales.value : null,
          federalFundsRate: federalFundsRate.status === "fulfilled" ? federalFundsRate.value : null,
          sectorPerformance: sectorPerformance.status === "fulfilled" ? sectorPerformance.value : null,
        },
        seasonal: seasonalData,
        businessType: businessType.trim(),
        location: location.trim(),
        timestamp: new Date().toISOString(),
      }
    } catch (error) {
      console.error("Error collecting forecasting data:", error)
      throw error
    }
  }

  private generateSeasonalPatterns(businessType: string) {
    console.log("[v0] generateSeasonalPatterns called with businessType:", businessType, typeof businessType)

    if (!businessType || typeof businessType !== "string" || businessType.trim().length === 0) {
      console.error("[v0] Invalid businessType in generateSeasonalPatterns:", businessType)
      businessType = "services" // Safe default
    }

    const safeBusinessType = businessType.toLowerCase().trim()
    console.log("[v0] Using safeBusinessType:", safeBusinessType)

    const patterns: Record<string, any> = {
      retail: {
        peak_months: [11, 12, 1], // Holiday season
        low_months: [2, 3, 4],
        factors: ["holidays", "weather", "consumer_spending"],
      },
      restaurant: {
        peak_months: [6, 7, 8, 12], // Summer and holidays
        low_months: [1, 2, 3],
        factors: ["weather", "tourism", "holidays"],
      },
      manufacturing: {
        peak_months: [9, 10, 11], // Pre-holiday production
        low_months: [1, 7, 8],
        factors: ["supply_chain", "demand_cycles", "raw_materials"],
      },
      services: {
        peak_months: [9, 10, 11],
        low_months: [1, 2, 3],
        factors: ["business_cycles", "seasonal_demand"],
      },
      ecommerce: {
        peak_months: [11, 12, 1],
        low_months: [2, 3, 4],
        factors: ["holidays", "online_shopping_trends", "marketing_campaigns"],
      },
      healthcare: {
        peak_months: [1, 2, 10, 11, 12], // Flu season and year-end
        low_months: [6, 7, 8],
        factors: ["seasonal_illness", "insurance_cycles", "preventive_care"],
      },
      technology: {
        peak_months: [9, 10, 11, 12], // Product launches and enterprise budgets
        low_months: [1, 2, 3],
        factors: ["product_cycles", "enterprise_budgets", "innovation_trends"],
      },
      construction: {
        peak_months: [4, 5, 6, 7, 8, 9], // Good weather months
        low_months: [12, 1, 2, 3],
        factors: ["weather", "seasonal_construction", "material_costs"],
      },
      default: {
        peak_months: [6, 7, 8],
        low_months: [1, 2, 3],
        factors: ["general_economic_activity"],
      },
    }

    const result = patterns[safeBusinessType] || patterns.default
    console.log("[v0] Returning seasonal pattern:", result)
    return result
  }

  async generateForecast(data: ForecastingData, historicalData: any[], timeHorizon = 12): Promise<ForecastResult> {
    try {
      console.log("[v0] generateForecast called with data keys:", Object.keys(data || {}))

      if (!data) {
        throw new Error("ForecastingData is required")
      }

      const prompt = this.buildOptimizedForecastingPrompt(data, historicalData, timeHorizon)

      const { text } = await generateText({
        model: groq("llama-3.1-8b-instant"),
        prompt: `You are an expert business forecasting AI that analyzes multiple data sources to predict operational metrics. Provide detailed, data-driven forecasts with confidence intervals and actionable recommendations.

${prompt}`,
        temperature: 0.3,
        maxTokens: 2000,
      })

      return this.parseForecastResponse(text, timeHorizon)
    } catch (error) {
      console.error("Error generating forecast:", error)
      throw error
    }
  }

  private buildOptimizedForecastingPrompt(data: ForecastingData, historical: any[], timeHorizon: number): string {
    const historicalSummary = this.summarizeHistoricalData(historical)
    const weatherSummary = this.summarizeWeatherData(data?.weather)
    const economicSummary = this.summarizeEconomicData(data?.economic)
    const seasonalSummary = data?.seasonal
      ? `Peak months: ${data.seasonal.peak_months?.join(", ")}, Low months: ${data.seasonal.low_months?.join(", ")}, Factors: ${data.seasonal.factors?.join(", ")}`
      : "No seasonal data available"

    return `
Analyze the following summarized data to generate operational forecasts for the next ${timeHorizon} months:

HISTORICAL TRENDS:
${historicalSummary}

WEATHER CONDITIONS:
${weatherSummary}

ECONOMIC INDICATORS:
${economicSummary}

SEASONAL PATTERNS:
${seasonalSummary}

EXTERNAL FACTORS:
Business Type: ${data?.external?.businessType || "Unknown"}
Location: ${data?.external?.location || "Unknown"}

Please provide forecasts for:
1. DEMAND - Monthly demand levels (0-100 scale)
2. PRODUCTION - Required production capacity (0-100 scale)
3. INVENTORY - Optimal inventory levels (0-100 scale)
4. STAFFING - Staffing requirements (0-100 scale)

Format your response as JSON:
{
  "demand": [array of ${timeHorizon} monthly values],
  "production": [array of ${timeHorizon} monthly values],
  "inventory": [array of ${timeHorizon} monthly values],
  "staffing": [array of ${timeHorizon} monthly values],
  "confidence": confidence_score_0_to_1,
  "factors": ["key_influencing_factors"],
  "recommendations": ["actionable_recommendations"]
}

Consider seasonality, weather impacts, economic trends, and provide realistic projections with actionable insights.
`
  }

  private parseForecastResponse(response: string | null, timeHorizon: number): ForecastResult {
    if (!response) {
      throw new Error("No response from AI model")
    }

    console.log("[v0] Raw AI response:", response)

    try {
      let parsedData: any = {}

      // Strategy 1: Look for complete JSON object first
      const completeJsonMatch = response.match(/\{[\s\S]*?\}/g)
      if (completeJsonMatch) {
        for (const jsonStr of completeJsonMatch) {
          try {
            const parsed = JSON.parse(jsonStr)
            parsedData = { ...parsedData, ...parsed }
            console.log("[v0] Successfully parsed complete JSON object")
            break
          } catch (e) {
            console.log("[v0] Failed to parse complete JSON, trying next match")
            continue
          }
        }
      }

      // Strategy 2: Extract individual JSON code blocks and combine them
      if (Object.keys(parsedData).length === 0) {
        console.log("[v0] Extracting individual JSON code blocks")
        const codeBlocks = response.match(/```(?:json)?\s*([^`]+)\s*```/g)

        if (codeBlocks) {
          for (const block of codeBlocks) {
            const content = block
              .replace(/```(?:json)?\s*/, "")
              .replace(/\s*```/, "")
              .trim()

            // Try to parse as complete JSON first
            try {
              const parsed = JSON.parse(content)
              parsedData = { ...parsedData, ...parsed }
              continue
            } catch (e) {
              // If not complete JSON, try to extract key-value pairs
              console.log("[v0] Extracting key-value pairs from code block")

              // Look for patterns like "key": [values] or "key": value
              const keyValueMatches = content.match(/"([^"]+)":\s*(\[[^\]]+\]|[^,\n}]+)/g)
              if (keyValueMatches) {
                for (const match of keyValueMatches) {
                  try {
                    const kvPair = `{${match}}`
                    const parsed = JSON.parse(kvPair)
                    parsedData = { ...parsedData, ...parsed }
                  } catch (kvError) {
                    console.log("[v0] Failed to parse key-value pair:", match)
                  }
                }
              }
            }
          }
        }
      }

      // Strategy 3: Extract from structured text if no JSON blocks found
      if (Object.keys(parsedData).length === 0) {
        console.log("[v0] Attempting to parse structured text")
        parsedData = this.extractFromStructuredText(response, timeHorizon)
      }

      console.log("[v0] Final parsed data:", parsedData)

      // Validate and ensure arrays have correct length
      const ensureArray = (arr: any[], defaultValue = 50) => {
        if (!Array.isArray(arr) || arr.length !== timeHorizon) {
          return Array(timeHorizon).fill(defaultValue)
        }
        return arr.map((val) => Math.max(0, Math.min(100, Number(val) || defaultValue)))
      }

      return {
        demand: ensureArray(parsedData.demand, 50),
        production: ensureArray(parsedData.production, 50),
        inventory: ensureArray(parsedData.inventory, 50),
        staffing: ensureArray(parsedData.staffing, 50),
        confidence: Math.max(0, Math.min(1, Number(parsedData.confidence) || 0.7)),
        factors: Array.isArray(parsedData.factors) ? parsedData.factors : [parsedData.factors || "general_trends"],
        recommendations: Array.isArray(parsedData.recommendations)
          ? parsedData.recommendations
          : [parsedData.recommendations || "Monitor key metrics"],
      }
    } catch (error) {
      console.error("Error parsing forecast response:", error)
      console.log("[v0] Falling back to default forecast")
      // Return default forecast
      return {
        demand: Array(timeHorizon).fill(50),
        production: Array(timeHorizon).fill(50),
        inventory: Array(timeHorizon).fill(50),
        staffing: Array(timeHorizon).fill(50),
        confidence: 0.5,
        factors: ["insufficient_data"],
        recommendations: ["Collect more historical data for better predictions"],
      }
    }
  }

  private extractFromStructuredText(response: string, timeHorizon: number): any {
    console.log("[v0] Parsing structured text response")

    const result: any = {}

    // Extract arrays from text patterns
    const extractNumbers = (text: string, key: string): number[] => {
      const patterns = [new RegExp(`${key}[^\\[]*\\[([^\\]]+)\\]`, "i"), new RegExp(`${key}[^0-9]*([0-9,\\s]+)`, "i")]

      for (const pattern of patterns) {
        const match = text.match(pattern)
        if (match) {
          const numbers = match[1]
            .split(/[,\s]+/)
            .map((n) => Number.parseInt(n.trim()))
            .filter((n) => !isNaN(n))

          if (numbers.length > 0) {
            // Ensure we have the right number of values
            while (numbers.length < timeHorizon) {
              numbers.push(numbers[numbers.length - 1] || 50)
            }
            return numbers.slice(0, timeHorizon)
          }
        }
      }
      return Array(timeHorizon).fill(50)
    }

    const extractArray = (text: string, key: string): string[] => {
      const pattern = new RegExp(`${key}[^\\[]*\\[([^\\]]+)\\]`, "i")
      const match = text.match(pattern)
      if (match) {
        return match[1].split(",").map((s) => s.trim().replace(/['"`]/g, ""))
      }
      return [`${key}_not_found`]
    }

    const extractConfidence = (text: string): number => {
      const match = text.match(/confidence[^0-9]*([0-9.]+)/i)
      if (match) {
        const conf = Number.parseFloat(match[1])
        return conf > 1 ? conf / 100 : conf // Handle percentage format
      }
      return 0.7
    }

    result.demand = extractNumbers(response, "demand")
    result.production = extractNumbers(response, "production")
    result.inventory = extractNumbers(response, "inventory")
    result.staffing = extractNumbers(response, "staffing")
    result.confidence = extractConfidence(response)
    result.factors = extractArray(response, "factors")
    result.recommendations = extractArray(response, "recommendations")

    return result
  }

  async generateInsights(forecastResult: ForecastResult, businessContext: any): Promise<string[]> {
    try {
      const prompt = `
Based on forecast results and business context, provide 5 actionable business insights:

FORECAST: Demand avg ${(forecastResult.demand.reduce((a, b) => a + b, 0) / forecastResult.demand.length).toFixed(1)}, Production avg ${(forecastResult.production.reduce((a, b) => a + b, 0) / forecastResult.production.length).toFixed(1)}, Confidence: ${forecastResult.confidence}

BUSINESS: ${businessContext.businessType} in ${businessContext.location}, ${businessContext.timeHorizon} month horizon

KEY FACTORS: ${forecastResult.factors.join(", ")}

Provide specific insights for resource planning, risk mitigation, and operational optimization. Format as JSON array of strings.
`

      const { text } = await generateText({
        model: groq("llama-3.1-8b-instant"),
        prompt: `You are a business strategy consultant providing actionable insights based on predictive analytics.

${prompt}`,
        temperature: 0.4,
        maxTokens: 800,
      })

      if (!text) return ["Monitor forecast accuracy and adjust strategies accordingly."]

      // Parse insights from response
      try {
        const insights = JSON.parse(text)
        return Array.isArray(insights) ? insights : [text]
      } catch {
        // If not JSON, split by lines and clean up
        return text
          .split("\n")
          .filter((line) => line.trim().length > 10)
          .map((line) => line.replace(/^[-•*]\s*/, "").trim())
          .slice(0, 7)
      }
    } catch (error) {
      console.error("Error generating insights:", error)
      return ["Monitor key performance indicators and adjust strategies based on forecast trends."]
    }
  }
}

export const forecastingEngine = new ForecastingEngine()
