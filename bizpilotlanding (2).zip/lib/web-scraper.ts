import { weatherAPI, worldBankAPI, alphaVantageAPI } from "./api-clients"

export interface ScrapedData {
  source: string
  type: "sales" | "inventory" | "staffing" | "market" | "competitor" | "financial" | "economic"
  data: any[]
  scrapedAt: string
  confidence: number
  metadata: {
    businessType: string
    location: string
    industry: string
  }
}

export interface ScrapingConfig {
  businessType: string
  industry: string
  location: string
  countryCode: string
  dataTypes: string[]
}

export class WebScraper {
  private readonly industryAPIs = {
    retail: {
      sales: ["Alpha Vantage Retail Sales", "US Census Bureau"],
      inventory: ["Alpha Vantage Inventory Indicators", "US Census Bureau"],
      market: ["Alpha Vantage Sector Performance", "Alpha Vantage Economic Indicators"],
      financial: ["Alpha Vantage Stock Data", "Alpha Vantage Economic Indicators"],
    },
    manufacturing: {
      production: ["Alpha Vantage Industrial Production", "US Census Bureau"],
      inventory: ["Alpha Vantage Manufacturing Indicators", "US Census Bureau"],
      market: ["Alpha Vantage Sector Performance", "Alpha Vantage Commodities"],
      financial: ["Alpha Vantage Stock Data", "Alpha Vantage Economic Indicators"],
    },
    restaurant: {
      sales: ["Alpha Vantage Consumer Sentiment", "US Census Bureau"],
      staffing: ["Alpha Vantage Employment Data", "Bureau of Labor Statistics"],
      market: ["Alpha Vantage Consumer Indicators", "Alpha Vantage Economic Data"],
      financial: ["Alpha Vantage Stock Data", "Alpha Vantage Economic Indicators"],
    },
    services: {
      sales: ["Alpha Vantage Service Sector", "US Census Bureau"],
      staffing: ["Alpha Vantage Employment Data", "Bureau of Labor Statistics"],
      market: ["Alpha Vantage Sector Performance", "Alpha Vantage Economic Indicators"],
      financial: ["Alpha Vantage Stock Data", "Alpha Vantage Economic Indicators"],
    },
    ecommerce: {
      sales: ["Alpha Vantage Retail Sales", "Alpha Vantage Consumer Sentiment"],
      inventory: ["Alpha Vantage Retail Indicators", "US Census Bureau"],
      market: ["Alpha Vantage E-commerce Trends", "Alpha Vantage Economic Data"],
      financial: ["Alpha Vantage Stock Data", "Alpha Vantage Economic Indicators"],
    },
    healthcare: {
      staffing: ["Alpha Vantage Employment Data", "Bureau of Labor Statistics"],
      market: ["Alpha Vantage Healthcare Sector", "Alpha Vantage Economic Indicators"],
      financial: ["Alpha Vantage Stock Data", "Alpha Vantage Economic Indicators"],
    },
    technology: {
      sales: ["Alpha Vantage Tech Sector", "US Census Bureau"],
      staffing: ["Alpha Vantage Employment Data", "Bureau of Labor Statistics"],
      market: ["Alpha Vantage Sector Performance", "Alpha Vantage Economic Indicators"],
      financial: ["Alpha Vantage Stock Data", "Alpha Vantage Economic Indicators"],
    },
    construction: {
      production: ["Alpha Vantage Construction Indicators", "US Census Bureau"],
      staffing: ["Alpha Vantage Employment Data", "Bureau of Labor Statistics"],
      market: ["Alpha Vantage Construction Sector", "Alpha Vantage Commodities"],
      financial: ["Alpha Vantage Stock Data", "Alpha Vantage Economic Indicators"],
    },
  }

  async scrapeIndustryData(config: ScrapingConfig): Promise<ScrapedData[]> {
    const results: ScrapedData[] = []

    try {
      const alphaVantageData = await this.scrapeAlphaVantageData(config)
      results.push(...alphaVantageData)

      // Get industry-specific data sources
      const industryConfig =
        this.industryAPIs[config.businessType as keyof typeof this.industryAPIs] || this.industryAPIs.services

      for (const dataType of config.dataTypes) {
        const sources = industryConfig[dataType as keyof typeof industryConfig] || []

        for (const source of sources) {
          try {
            const data = await this.scrapeDataSource(source, dataType, config)
            if (data) {
              results.push(data)
            }
          } catch (error) {
            console.error(`Failed to scrape ${source}:`, error)
            // Continue with other sources
          }
        }
      }

      // Add synthetic data based on business type and location
      const syntheticData = await this.generateSyntheticData(config)
      results.push(...syntheticData)

      return results
    } catch (error) {
      console.error("Error scraping industry data:", error)
      return this.getFallbackData(config)
    }
  }

  private async scrapeAlphaVantageData(config: ScrapingConfig): Promise<ScrapedData[]> {
    const results: ScrapedData[] = []

    try {
      console.log("[v0] Scraping Alpha Vantage financial data...")

      // Collect economic indicators
      const [
        realGDP,
        inflationRate,
        unemploymentRate,
        consumerSentiment,
        retailSales,
        federalFundsRate,
        sectorPerformance,
      ] = await Promise.allSettled([
        alphaVantageAPI.getRealGDP(),
        alphaVantageAPI.getInflationRate(),
        alphaVantageAPI.getUnemploymentRate(),
        alphaVantageAPI.getConsumerSentiment(),
        alphaVantageAPI.getRetailSales(),
        alphaVantageAPI.getFederalFundsRate(),
        alphaVantageAPI.getSectorPerformance(),
      ])

      // Process Real GDP data
      if (realGDP.status === "fulfilled" && realGDP.value) {
        results.push({
          source: "Alpha Vantage - Real GDP",
          type: "economic",
          data: this.processAlphaVantageEconomicData(realGDP.value, "GDP"),
          scrapedAt: new Date().toISOString(),
          confidence: 0.95,
          metadata: {
            businessType: config.businessType,
            location: config.location,
            industry: config.industry,
          },
        })
      }

      // Process Inflation data
      if (inflationRate.status === "fulfilled" && inflationRate.value) {
        results.push({
          source: "Alpha Vantage - Inflation Rate",
          type: "economic",
          data: this.processAlphaVantageEconomicData(inflationRate.value, "Inflation"),
          scrapedAt: new Date().toISOString(),
          confidence: 0.95,
          metadata: {
            businessType: config.businessType,
            location: config.location,
            industry: config.industry,
          },
        })
      }

      // Process Unemployment data
      if (unemploymentRate.status === "fulfilled" && unemploymentRate.value) {
        results.push({
          source: "Alpha Vantage - Unemployment Rate",
          type: "economic",
          data: this.processAlphaVantageEconomicData(unemploymentRate.value, "Unemployment"),
          scrapedAt: new Date().toISOString(),
          confidence: 0.95,
          metadata: {
            businessType: config.businessType,
            location: config.location,
            industry: config.industry,
          },
        })
      }

      // Process Consumer Sentiment data
      if (consumerSentiment.status === "fulfilled" && consumerSentiment.value) {
        results.push({
          source: "Alpha Vantage - Consumer Sentiment",
          type: "market",
          data: this.processAlphaVantageEconomicData(consumerSentiment.value, "Consumer Sentiment"),
          scrapedAt: new Date().toISOString(),
          confidence: 0.9,
          metadata: {
            businessType: config.businessType,
            location: config.location,
            industry: config.industry,
          },
        })
      }

      // Process Retail Sales data
      if (retailSales.status === "fulfilled" && retailSales.value) {
        results.push({
          source: "Alpha Vantage - Retail Sales",
          type: "sales",
          data: this.processAlphaVantageEconomicData(retailSales.value, "Retail Sales"),
          scrapedAt: new Date().toISOString(),
          confidence: 0.9,
          metadata: {
            businessType: config.businessType,
            location: config.location,
            industry: config.industry,
          },
        })
      }

      // Process Sector Performance data
      if (sectorPerformance.status === "fulfilled" && sectorPerformance.value) {
        results.push({
          source: "Alpha Vantage - Sector Performance",
          type: "market",
          data: this.processAlphaVantageSectorData(sectorPerformance.value, config.businessType),
          scrapedAt: new Date().toISOString(),
          confidence: 0.85,
          metadata: {
            businessType: config.businessType,
            location: config.location,
            industry: config.industry,
          },
        })
      }

      console.log(`[v0] Successfully scraped ${results.length} Alpha Vantage datasets`)
      return results
    } catch (error) {
      console.error("Error scraping Alpha Vantage data:", error)
      return []
    }
  }

  private processAlphaVantageEconomicData(apiResponse: any, indicator: string): any[] {
    try {
      // Alpha Vantage economic data typically comes in a "data" array
      const data = apiResponse?.data || []

      return data.slice(0, 12).map((item: any, index: number) => ({
        period: item.date || `2024-${String(12 - index).padStart(2, "0")}`,
        value: Number.parseFloat(item.value) || 0,
        indicator,
        source: "Alpha Vantage",
        dataType: "economic",
      }))
    } catch (error) {
      console.error(`Error processing Alpha Vantage ${indicator} data:`, error)
      return []
    }
  }

  private processAlphaVantageSectorData(apiResponse: any, businessType: string): any[] {
    try {
      // Map business types to relevant sectors
      const sectorMapping: Record<string, string> = {
        retail: "Consumer Discretionary",
        manufacturing: "Industrials",
        restaurant: "Consumer Discretionary",
        services: "Services",
        ecommerce: "Technology",
        healthcare: "Health Care",
        technology: "Information Technology",
        construction: "Real Estate",
      }

      const relevantSector = sectorMapping[businessType] || "Services"

      // Process sector performance data
      const sectorData = apiResponse?.["Rank A: Real-Time Performance"] || {}

      return Object.entries(sectorData).map(([sector, performance]: [string, any]) => ({
        sector,
        performance: Number.parseFloat(performance) || 0,
        relevantToBusinessType: sector.includes(relevantSector),
        source: "Alpha Vantage",
        dataType: "sector_performance",
        scrapedAt: new Date().toISOString(),
      }))
    } catch (error) {
      console.error("Error processing Alpha Vantage sector data:", error)
      return []
    }
  }

  private async scrapeDataSource(
    source: string,
    dataType: string,
    config: ScrapingConfig,
  ): Promise<ScrapedData | null> {
    try {
      // For demo purposes, we'll generate realistic data based on the source and config
      // In a real implementation, you would make actual API calls to these sources

      const mockData = this.generateMockDataForSource(source, dataType, config)

      return {
        source,
        type: dataType as any,
        data: mockData,
        scrapedAt: new Date().toISOString(),
        confidence: 0.8,
        metadata: {
          businessType: config.businessType,
          location: config.location,
          industry: config.industry,
        },
      }
    } catch (error) {
      console.error(`Error scraping ${source}:`, error)
      return null
    }
  }

  private generateMockDataForSource(source: string, dataType: string, config: ScrapingConfig): any[] {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    const currentYear = new Date().getFullYear()

    // Generate seasonal patterns based on business type
    const seasonalMultipliers = this.getSeasonalMultipliers(config.businessType)

    return months.map((month, index) => {
      const baseValue = this.getBaseValueForDataType(dataType, config.businessType)
      const seasonal = seasonalMultipliers[index]
      const randomVariation = 0.8 + Math.random() * 0.4 // ±20% variation

      return {
        period: `${currentYear}-${String(index + 1).padStart(2, "0")}`,
        month,
        value: Math.round(baseValue * seasonal * randomVariation),
        dataType,
        source: this.getSourceName(source),
        location: config.location,
        businessType: config.businessType,
      }
    })
  }

  private getSeasonalMultipliers(businessType: string): number[] {
    const patterns: Record<string, number[]> = {
      retail: [0.8, 0.7, 0.8, 0.9, 1.0, 1.1, 1.0, 1.0, 1.1, 1.2, 1.4, 1.6], // Holiday peak
      restaurant: [0.8, 0.8, 0.9, 1.0, 1.1, 1.3, 1.4, 1.3, 1.1, 1.0, 0.9, 1.2], // Summer + holidays
      manufacturing: [0.9, 0.9, 1.0, 1.1, 1.1, 1.0, 0.9, 0.9, 1.2, 1.3, 1.2, 1.0], // Pre-holiday production
      services: [0.9, 0.9, 1.0, 1.1, 1.1, 1.1, 1.0, 1.0, 1.2, 1.2, 1.1, 1.0],
      ecommerce: [0.8, 0.8, 0.9, 1.0, 1.0, 1.1, 1.0, 1.0, 1.1, 1.2, 1.5, 1.7], // Strong holiday peak
      healthcare: [1.2, 1.3, 1.1, 1.0, 0.9, 0.8, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3], // Flu season
      technology: [0.9, 0.9, 1.0, 1.0, 1.1, 1.1, 1.0, 1.0, 1.2, 1.3, 1.3, 1.2], // Enterprise budgets
      construction: [0.7, 0.8, 1.0, 1.2, 1.4, 1.4, 1.3, 1.3, 1.2, 1.1, 0.9, 0.7], // Weather dependent
    }

    return patterns[businessType] || patterns.services
  }

  private getBaseValueForDataType(dataType: string, businessType: string): number {
    const baseValues: Record<string, Record<string, number>> = {
      sales: {
        retail: 100000,
        restaurant: 50000,
        manufacturing: 200000,
        services: 75000,
        ecommerce: 150000,
        healthcare: 120000,
        technology: 300000,
        construction: 250000,
      },
      inventory: {
        retail: 50000,
        manufacturing: 100000,
        ecommerce: 75000,
        construction: 150000,
      },
      staffing: {
        retail: 25,
        restaurant: 15,
        manufacturing: 50,
        services: 30,
        healthcare: 40,
        technology: 35,
        construction: 45,
      },
      production: {
        manufacturing: 1000,
        construction: 500,
      },
      market: {
        retail: 1000000,
        restaurant: 500000,
        manufacturing: 2000000,
        services: 750000,
        ecommerce: 1500000,
        healthcare: 1200000,
        technology: 3000000,
        construction: 2500000,
      },
      financial: {
        retail: 100000,
        manufacturing: 200000,
        restaurant: 50000,
        services: 75000,
        ecommerce: 150000,
        healthcare: 120000,
        technology: 300000,
        construction: 250000,
      },
      economic: {
        retail: 100000,
        manufacturing: 200000,
        restaurant: 50000,
        services: 75000,
        ecommerce: 150000,
        healthcare: 120000,
        technology: 300000,
        construction: 250000,
      },
    }

    return baseValues[dataType]?.[businessType] || 50000
  }

  private getSourceName(url: string): string {
    if (url.includes("census.gov")) return "US Census Bureau"
    if (url.includes("bls.gov")) return "Bureau of Labor Statistics"
    if (url.includes("Alpha Vantage")) return "Alpha Vantage"
    return "Industry Data Source"
  }

  private async generateSyntheticData(config: ScrapingConfig): Promise<ScrapedData[]> {
    const results: ScrapedData[] = []

    try {
      // Generate location-specific economic data
      const economicData = await worldBankAPI.getGDPData(config.countryCode)
      const weatherData = await weatherAPI.getCurrentWeather(config.location)

      // Create synthetic market data based on economic indicators
      const marketData: ScrapedData = {
        source: "Economic Indicators API",
        type: "market",
        data: this.generateMarketDataFromEconomics(economicData, config),
        scrapedAt: new Date().toISOString(),
        confidence: 0.9,
        metadata: {
          businessType: config.businessType,
          location: config.location,
          industry: config.industry,
        },
      }

      results.push(marketData)

      // Generate weather-influenced data for relevant business types
      if (["retail", "restaurant", "construction"].includes(config.businessType)) {
        const weatherInfluencedData: ScrapedData = {
          source: "Weather Impact Analysis",
          type: "sales",
          data: this.generateWeatherInfluencedData(weatherData, config),
          scrapedAt: new Date().toISOString(),
          confidence: 0.7,
          metadata: {
            businessType: config.businessType,
            location: config.location,
            industry: config.industry,
          },
        }

        results.push(weatherInfluencedData)
      }
    } catch (error) {
      console.error("Error generating synthetic data:", error)
    }

    return results
  }

  private generateMarketDataFromEconomics(economicData: any, config: ScrapingConfig): any[] {
    // Generate market trends based on economic indicators
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    const currentYear = new Date().getFullYear()

    return months.map((month, index) => ({
      period: `${currentYear}-${String(index + 1).padStart(2, "0")}`,
      month,
      marketSize: this.getBaseValueForDataType("market", config.businessType) * (1 + Math.random() * 0.1),
      growthRate: 2 + Math.random() * 8, // 2-10% growth
      competitorCount: 10 + Math.floor(Math.random() * 20),
      marketShare: 5 + Math.random() * 15, // 5-20% market share
      source: "Economic Analysis",
      location: config.location,
    }))
  }

  private generateWeatherInfluencedData(weatherData: any, config: ScrapingConfig): any[] {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    const currentYear = new Date().getFullYear()

    return months.map((month, index) => {
      const baseTemp = 15 + Math.sin(((index - 3) * Math.PI) / 6) * 15 // Seasonal temperature
      const weatherMultiplier = this.getWeatherMultiplier(config.businessType, baseTemp)

      return {
        period: `${currentYear}-${String(index + 1).padStart(2, "0")}`,
        month,
        value: this.getBaseValueForDataType("sales", config.businessType) * weatherMultiplier,
        temperature: baseTemp,
        weatherImpact: weatherMultiplier,
        source: "Weather Analysis",
        location: config.location,
      }
    })
  }

  private getWeatherMultiplier(businessType: string, temperature: number): number {
    switch (businessType) {
      case "restaurant":
        // Restaurants do better in moderate weather
        return 0.8 + 0.4 * Math.exp(-Math.pow((temperature - 22) / 15, 2))
      case "retail":
        // Retail peaks during shopping seasons (cooler weather)
        return temperature < 10 ? 1.2 : temperature > 30 ? 0.9 : 1.0
      case "construction":
        // Construction is weather dependent
        return temperature < 5 ? 0.5 : temperature > 35 ? 0.7 : 1.0 + (temperature - 15) * 0.02
      default:
        return 1.0
    }
  }

  private getFallbackData(config: ScrapingConfig): ScrapedData[] {
    // Return basic synthetic data if all scraping fails
    return [
      {
        source: "Fallback Data Generator",
        type: "sales",
        data: this.generateMockDataForSource("fallback", "sales", config),
        scrapedAt: new Date().toISOString(),
        confidence: 0.5,
        metadata: {
          businessType: config.businessType,
          location: config.location,
          industry: config.industry,
        },
      },
    ]
  }

  async scrapeCompetitorData(config: ScrapingConfig): Promise<ScrapedData[]> {
    // In a real implementation, this would scrape competitor websites, social media, etc.
    // For now, we'll generate realistic competitor data

    const competitors = this.getCompetitorList(config.businessType)
    const results: ScrapedData[] = []

    for (const competitor of competitors) {
      const competitorData: ScrapedData = {
        source: `Competitor Analysis - ${competitor}`,
        type: "competitor",
        data: this.generateCompetitorData(competitor, config),
        scrapedAt: new Date().toISOString(),
        confidence: 0.6,
        metadata: {
          businessType: config.businessType,
          location: config.location,
          industry: config.industry,
        },
      }

      results.push(competitorData)
    }

    return results
  }

  private getCompetitorList(businessType: string): string[] {
    const competitors: Record<string, string[]> = {
      retail: ["Amazon", "Walmart", "Target", "Local Retailers"],
      restaurant: ["McDonalds", "Starbucks", "Local Restaurants", "Food Trucks"],
      manufacturing: ["Industry Leader A", "Industry Leader B", "Regional Manufacturers"],
      services: ["Service Provider A", "Service Provider B", "Local Services"],
      ecommerce: ["Amazon", "eBay", "Shopify Stores", "Direct-to-Consumer Brands"],
      healthcare: ["Hospital Systems", "Clinics", "Telehealth Providers"],
      technology: ["Tech Giants", "Startups", "Enterprise Solutions"],
      construction: ["Construction Companies", "Contractors", "Specialty Builders"],
    }

    return competitors[businessType] || competitors.services
  }

  private generateCompetitorData(competitor: string, config: ScrapingConfig): any[] {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    const currentYear = new Date().getFullYear()

    return months.map((month, index) => ({
      period: `${currentYear}-${String(index + 1).padStart(2, "0")}`,
      month,
      competitor,
      estimatedRevenue: this.getBaseValueForDataType("sales", config.businessType) * (0.5 + Math.random()),
      marketShare: 5 + Math.random() * 25,
      customerSatisfaction: 3.5 + Math.random() * 1.5,
      pricingIndex: 0.8 + Math.random() * 0.4,
      location: config.location,
    }))
  }
}

export const webScraper = new WebScraper()
